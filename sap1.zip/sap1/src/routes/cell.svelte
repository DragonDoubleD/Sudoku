<script>
  import { createEventDispatcher } from "svelte"; //used to dispatch component events

  export let cell;
  export let activePosition;
  export let highlightValue;

  const options = [1, 2, 3, 4, 5, 6, 7, 8, 9];

  const dispatch = createEventDispatcher();

  const cellClicked = e => { //e for event
    const element = e.currentTarget.querySelector("input");
    //currentTarget returns the element whose event listener triggerd the event
    element.focus();
    //focusses theinput that was inerted into the cell

    dispatch("highlight", cell.value);
    dispatch("change-navigation", cell.position);
  };
</script>


<div
  class={`
  container
  ${cell.readonly ? 'readOnly' : 'notReadOnly'}
  ${cell.error ? 'hasError' : ''}
  ${cell.position === activePosition ? 'keyboardActive' : ''}
  ${highlightValue && cell.value === highlightValue ? 'highlight' : ''}`}
  
  on:click={cellClicked}>
  <input bind:value={cell.value} disabled={cell.readonly} type="text" />
  {#if !cell.value}
    <ul class="pencil-container">
      {#each options as option}
        <li
          class={`option option${option} ${cell.pencil.has(option) ? 'visibleOption' : ''}`}>
           {option}
        </li>
      {/each}
    </ul>
  {/if}
</div>

<style>
  input {
    background-color: black;
    color: white;
    height: 100%;
    margin: 0;
    outline: none;
    text-align: center;
    user-select: none;
    width: 100%;
  }

  input:disabled {
    background-color: #2e2e2e;
    color: #afafaf;
    font-weight: bold;
  }
  .container {
    height: 100%;
  }
  .pencil-container {
    display: grid;
    font-size: 8px;
    grid:
      "option1 option2 option3"
      "option4 option5 option6"
      "option7 option8 option9";
    height: 100%;
    left: 0;
    position: absolute;
    text-align: center;
    top: 0;
    width: 100%;
    background-color: red;
  }

  .option {
    align-items: center;
    color: transparent;
    display: flex;
    justify-content: center;
  }

  .visibleOption {
    color: darkslategray;
  }

  .option1 {
    grid-area: option1;
  }
  .option2 {
    grid-area: option2;
  }
  .option3 {
    grid-area: option3;
  }
  .option4 {
    grid-area: option4;
  }
  .option5 {
    grid-area: option5;
  }
  .option6 {
    grid-area: option6;
  }
  .option7 {
    grid-area: option7;
  }
  .option8 {
    grid-area: option8;
  }
  .option9 {
    grid-area: option9;
  }

  .hasError input { /* highlights cell with wrong input */
    background-color: red;
    text-shadow: 0 0 0 salmon;
  }

  .keyboardActive {
    background-color: blue;
  }

  .keyboardActive input { /* current input field */
    background-color: #c27c90;
  }

  .highlight {
    background-color: #c27c90;
  }

  .highlight input {
    background-color: #c27c90;
  }
</style>