<script>
	function goToCategory(){
		window.location.href = "/category";
	}
	function goToManual(){
		window.location.href = "/manual";
	}
</script>

<header>
<div class="header"><img src="favicon.png" alt="logo" height= "100px" width= "auto"></div>


<main class="container">
	<img class="img" alt='Success Kid' src='index2.png' >
	<button class="button play" on:click={goToCategory}>Sudoku</button>
	<button class="button manual" on:click={goToManual}>Anleitung</button>
</main>

<style>
@media (min-width: 1920px){
main{
	   	background-color: black;
		width: 100%;
		height: 100%;
		position: absolute;
		overflow: auto;
		z-index: 1;
    }
button {
		color: green;
		text-align: center;
		font-size: 18px;
		font-family:  Calibri;
		font-weight: 10;
		letter-spacing: 0.03em;
		border: none;
		border-radius: 0.1em;
		height: 50px;
		width: 190px;
		cursor: pointer;
		display: block;
		margin-right: auto;
		margin-bottom: 15px;
		margin-left: auto;
	}
.header {
		background-color: #f8e1e7;
		width: 100%;
		height: 50px;
		position: fixed;
		z-index: 2;
	}
	.container {
		display: grid;
		justify-content: center;
		align-items: center;
		grid-template-rows: auto;
		height: 100%;
	}
img {
    height: 50px;
    width: auto;
}
	.play {
		background-color: #c27c90;
	} 
	.play:hover {
		background-color:  #b6637a;
	} 
	:global(.manual) {
		background-color: #65444e;
	} 
	:global(.manual:hover) {
		background-color: #4d333b;
	}    
	img.img{
	height:650px;
    width:auto;
	margin-top: 15%;
	margin-bottom:3%;
}
	
}






@media (min-width:2000px){

main{
	   	background-color: black;
		width: 100%;
		height: 100%;
		position: absolute;
		overflow: auto;
		z-index: 1;
    }

button {
		color: yellow;
		text-align: center;
		font-size: 45px;
		font-family:  Calibri;
		font-weight: 10;
		letter-spacing: 0.03em;
		border: none;
		border-radius: 0.1em;
		height: 80px;
		width: 270px;
		cursor: pointer;
		display: block;
		margin-right: auto;
		margin-left: auto;
		
	}
.header {
	background-color: #f8e1e7;
		width: 100%;
		height: 50px;
		position: fixed;
		z-index: 2;
		
	}
	.play {
		background-color: #c27c90;
	} 
	.play:hover {
		background-color:  #b6637a;
	} 
	:global(.manual) {
		background-color: #65444e;
	} 
	:global(.manual:hover) {
		background-color: #4d333b;
	}     
	.container {
		display: grid;
		justify-content: center;
		align-items: center;
		grid-template-rows: auto;
		height: 100%;
	}
.header {
    width: 100%;
	height: 100px;
}
img {
    height:100px;
    width:auto;
}
img.img{
	height:950px;
    width:auto;
	margin-top: 15%;
	margin-bottom:3%;
}

	}

</style>

</header>