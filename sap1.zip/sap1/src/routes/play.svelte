<script>
  import Category from "./category.svelte";
  import Cell from "./cell.svelte";
  import * as utils from "./utils";
  import { tweened } from 'svelte/motion';

  let url = window.location.search;
  let selectedDifficult = url.replace("?difficult=", '');

  //Timer
  let value = 0;
  let timer = tweened(value);
  setInterval(() => {
    $timer++;
  }, 1000);

  function formatValue(val) {
    var valString = val + "";
    if (valString.length < 2) {
      return "0" + valString;
    } else {
      return valString;
    }
  }

  $: minutes = formatValue(Math.floor($timer / 60));
  $: minname = minutes > 1 ? "mins" : "min";
  $: seconds = formatValue(Math.floor($timer - minutes * 60));

  function changeIcon() {
    let x = document.getElementById("pause");
    if (x.innerHTML === "||") {
     x.innerHTML = "&#x25BA";
       stopTimer();     } else {
     x.innerHTML = "||";
    }
  }

  function check() {
     
  }

  function restart() {
    location.reload(); 
  }







  function stopTimer(e) {
     e.preventDefault();
     isPaused = true;
   }

 
   let gridWithDifficult;
 let gridWithBlockInfo;
  let activePosition = 0;
   let highlightValue = null;

   const startGame = difficult => {
   const grid = utils.generateGrid(3);
    const filledGrid = utils.fillGrid(grid, 3);
     gridWithDifficult = utils.applyGameDifficult(selectedDifficult, filledGrid);
   gridWithBlockInfo = utils.includeBlockInfo(gridWithDifficult, 3);
   };

   const handlePen = ({ detail: { value, position } }) => {
     const isLegal = utils.isLegal(gridWithDifficult, position, value);
     gridWithBlockInfo = gridWithBlockInfo.map(cell => {
      if (cell.position !== position) {
        return cell;
     }

      return {
         ...cell,
         value: value !== 0 ? value : null,
        error: value === 0 ? false : !isLegal
       };
    });
    gridWithDifficult[position] = value;
       };

   const handlePencil = ({ detail: { value, position } }) => {
     if (value === 0) return;

   gridWithBlockInfo = gridWithBlockInfo.map(cell => {
      if (cell.position !== position) {
         return cell;
      }

     const isAlreadyThere = cell.pencil.has(value);
       if (isAlreadyThere) {
         cell.pencil.delete(value);
       } else {
         cell.pencil.add(value);
       }

       return cell;
   });
  };
   function pause() {
     changeIcon();
     stopTimer();

  }
   
 

   const handleChangeNavigation = ({ detail: value }) => {
    activePosition = value;
   };

   const handleHighlight = ({ detail: value }) => {
     if (highlightValue === value) {
      highlightValue = null;
     } else {
      highlightValue = value;
     }
   };

   $: groupedGrid = utils.groupByBlock(gridWithBlockInfo);

   $: errors = utils.getErrors(gridWithBlockInfo);
   $: missingValues = utils.getMissingValues(gridWithBlockInfo, errors);
   $: isVictory = missingValues === 0;
   startGame(selectedDifficult);

  window.addEventListener("keydown", e => {
    e.preventDefault();
     const { key, ctrlKey } = e;
    const [isValid, action] = utils.validateKeyInteraction(key, activePosition);
     if (!isValid) return;
     if (action !== "digit") {
       activePosition = utils.getNewActivePosition(activePosition, action);
    } else {
      const cell = gridWithBlockInfo[activePosition];
       if (cell.readonly) return;

       const event = {
         detail: {
           value: parseInt(key, 10),
           position: activePosition
        }
      };

      ctrlKey ? handlePencil(event) : handlePen(event);
    }
   });

 function goToCategories() {
     window.location.href="/category";
   }

     function goToManual() {
  
     window.location.href="/manual";
  }
</script>

<header>
	<div class="header"><img src="favicon.png" alt="logo" height= "50px" width= "auto"></div>
</header>

<main>
  <button name="back" class="back manual" on:click={goToCategories}>&#8617</button>
  <button name="info" class="info" on:click={goToManual}>i</button>

  <div class="container">
  
    <div class="grid">
      {#each groupedGrid as block}
        <div class="block">
          {#each block as cell}
            <div class="cell">
              <Cell
                on:change-navigation={handleChangeNavigation}
                on:highlight={handleHighlight}
                on:pen={handlePen}
                on:pencil={handlePencil}
                {cell}
                {activePosition}
                {highlightValue} />
            </div>
          {/each}
        </div>
      {/each}
    </div>
      <div class="menue">
      <div></div>
        <div class="timer">{minutes}:{seconds}<button id="pause" class="pause" on:click={pause}>||</button></div>
        <button class="button" id="check" on:click={check}>Überprüfen</button>
        <button class="button" id="tip" on:click={tip}>Hinweise</button>
        <button class="button" id="restart" on:click={restart}>Neu starten</button>
      </div>
  </div>
</main> -->




<style>
@media (min-width: 1920px){
  .grid:enabled {
    z-index: 1;
  }
  .container {
    display: flex;
    justify-content: center;

  }
  .grid {
    display: grid;
    background-color: blue;
    grid-template-columns: auto auto auto;
    width: 620px;
    height: 620px;
    grid-gap: 6px;
  

  }
  .block {
    display: grid;
    grid-template-columns: auto auto auto;
  }
  .cell {
    display: grid;
    /* height: calc(620px / 9); */
    height: auto;
     grid-template-columns: auto auto auto;
    justify-content: center;
    position: relative;
    user-select: none;
    width: auto;
    cursor: pointer;
    border: 1px solid white;
  }
  .menue {
    display: grid;
    justify-content: center;
    height: 350px;
    width: 250px;
    grid-template-rows: 20px auto auto auto auto;
    border: 3px solid white;
    margin-left: 200px;
    
  }
    .timer {
    color: white;
    text-align: left;
  	font-size: 22px;
		font-family: Calibri;
		font-weight: 10;
  }
  .pause {
    height: 40px;
    width: 40px;
    color: white;
    background-color: #c27c90;
    margin-left: 40px;
    font-size: 20px;
    font-weight: 700;
    font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif; 
		border: none;
		border-radius: 50%;
    text-align: center;
  }
  .info {
    color: white;
    background-color: #c27c90;
    height: 45px;
		width: 45px;
    justify-content: center;
    display: block;
    font-size: 35px;
    font-weight: 900;
    font-family: 'Times New Roman', Times, serif; 
		border: none;
		border-radius: 50%;
    margin-top: -55px;
		margin-left: 95%;
  }
  .header{
    background-color: #f8e1e7;
		width: 100%;
		height: 50px;
		position: fixed;
		z-index: 2;
    }

    button {
		color: green;
		text-align: center;
		font-size: 18px;
		font-family:  Calibri;
		font-weight: 10;
		letter-spacing: 0.03em;
		border: none;
		border-radius: 0.1em;
		height: 50px;
		width: 190px;
		cursor: pointer;
		display: block;
		
	}


  #check {
    background-color: #e182ac;
   
  }
  #tip {
    background-color: #c27c90;
  
  }
  #restart {
    background-color: #9c4d5f;
  
  }
  main{
	   	background-color: black;
		width: 100%;
		height: 100%;
		position: absolute;
		overflow: auto;
		z-index: 1;
    }
}




@media (min-width:2000px){
  
.grid:enabled {
    z-index: 1;
  }
  .container {
    display: flex;
    justify-content: center;

  }
  .grid {
    display: grid;
    background-color: blue;
    grid-template-columns: auto auto auto;
    width: 900px;
    height: 900px;
    grid-gap: 6px;
  

  }
  .block {
    display: grid;
    grid-template-columns: auto auto auto;
  }
  .cell {
    display: grid;
    /* height: calc(620px / 9); */
    height: auto;
     grid-template-columns: auto auto auto;
    justify-content: center;
    position: relative;
    user-select: none;
    width: auto;
    cursor: pointer;
    border: 1px solid white;
  }
  .menue {
    display: grid;
    justify-content: center;
    height: 450px;
    width: 350px;
    grid-template-rows: 20px auto auto auto auto;
    border: 3px solid white;
    margin-left: 200px;
    
  }
    .timer {
    color: white;
    text-align: right;
  	font-size: 45px;
		font-family: Calibri;
		font-weight: 10;
  }
  .pause {
    height: 55px;
    width: 55px;
    color: white;
    background-color: #c27c90;
    margin-left: 30px;
    font-size: 35px;
    font-weight: 700;
    font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif; 
		border: none;
		border-radius: 50%;
    text-align: center;
  }
  .info {
    color: white;
    background-color: #c27c90;
    height: 55px;
		width: 55px;
    justify-content: center;
    display: block;
    font-size: 40px;
    font-weight: 900;
    font-family: 'Times New Roman', Times, serif; 
		border: none;
		border-radius: 50%;
    margin-top: 10px;
		margin-left: 90%;
  }
  .button {
		color: yellow;
		text-align: center;
		font-size: 30px;
		font-family:  Calibri;
		font-weight: 10;
		letter-spacing: 0.03em;
		border: none;
		border-radius: 0.1em;
	  height: 65px;
		width: 200px;
		cursor: pointer;
		display: block;
		margin-right: auto;
		margin-bottom: 15px;
		margin-left: auto;
	}


  #check {
    background-color: #e182ac;
   
  }
  #tip {
    background-color: #c27c90;
  
  }
  #restart {
    background-color: #9c4d5f;
  
  }
  .header {
    width: 100%;
	height: 100px;
}
img {
    height:100px;
    width:auto;
}
.header {
    width: 100%;
	height: 100px;
    background-color: #f8e1e7;
}
main{
	   	background-color: black;
		width: 100%;
		height: 100%;
		position: absolute;
		overflow: auto;
		z-index: 1;
    }
  }
</style> 