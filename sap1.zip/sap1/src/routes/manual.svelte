<script>

function goBack() {
    window.location.href = "/";
}
</script>

<header>
<div class="header"><img src="favicon.png" alt="logo"></div>

<main>
<button name="back" class="back manual"  on:click={goBack}>&#8617</button>

<body>
<div style ="border:5px solid #e17795; margin-left:5%;margin-right:5%; margin-top:2%;">
<p>
Das Logikrätsel "Sudoku" besteht aus einem Spielfeld von 3x3 Blöcken, in denen jeweils 9 Kästchen gegeben sind.
Insgesamt verfügt das Spielfeld 81 Kästchen, die mit den Ziffern von 1 bis 9 ausgefüllt werden können.
Das Ziel des Spiels ist es, das Sudoku in möglichst kurzer Zeit zu vervollständigen.
Beim Starten des Spiels sind bereits einige Felder mit vorgegebenen Ziffern bedeckt, die nicht veränderbar sind.
So müssen die leeren Delder mit den Zahlen 1 bis 9 bedeckt werden. Folgende Regeln sind einzuhalten:
</p>
<p>In jeder Zeile dürfen die Ziffern von 1 bis 9 nur einmal vorkommen</p>
<p>In jeder Spalte dürfen die Ziffern von 1 bis 9 nur einmal vorkommen</p>
<p>In jedem Block dürfen die Ziffern von 1 bis 9 nur einmal vorkommen</p>
</div>
</body>


<style> 
@media (min-width: 1920px){
main{
  background-color: black;
  width: 100%;
  height: 100%;
  }

body {
  color:white; 
  font-size:30px;
  font-family: arial;
  }
p{
  margin-left: 1%;
  margin-right:1%;
}
img {
    height: 50px;
    width: auto;
}
.back {
  
    margin-bottom:2%;
}
main{
	   	background-color: black;
		width: 100%;
		height: 100%;
		position: absolute;
		overflow: auto;
		z-index: 1;
    }
    .header{
        background-color: #f8e1e7;
		width: 100%;
		height: 50px;
		position: fixed;
		z-index: 2;
    }
}



@media (min-width:2000px){
main{
	   	background-color: black;
		width: 100%;
		height: 100%;
		position: absolute;
		overflow: auto;
		z-index: 1;
    }

.back {
    height: 6%;
    width: 4%;
    margin-bottom:2%;
}

body {
  color:white; 
  font-size:50px;
  font-family: arial;
  }

p{
  margin-left: 1%;
  margin-right:1%;
}
.header {
    width: 100%;
	height: 100px;
    background-color: #f8e1e7;
}
img {
    height:100px;
    width:auto;
}

}
</main>
  </style>
  </header>