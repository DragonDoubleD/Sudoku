<script>
	import { createEventDispatcher } from "svelte";
	import { onMount } from "svelte";

	let selectedDifficult= "medium";

	const dispatch = createEventDispatcher();
	
	const handleChange = difficult => {
	 	dispatch("change-difficult", difficult);
	
		window.location.href = "/play?difficult="+difficult;

	}

	
	const levels = ["easy", "medium", "hard"];
  	const levelText = {
		easy: "Einfach",
		medium: "Mittel",
		hard: "Profi",
  	};

	function goBack() {
		window.history.back();
	}
	function goToManual(){
		window.location.href = "/manual";
	}
</script>

<header>
	<div class="header"><img src="favicon.png" alt="logo" height= "50px" width= "auto"></div>
</header>

<main>
	<button name="back" class="back manual" on:click={goBack}>&#8617</button>
		
	<div class="container">

		<button class="category {levels[0] === selectedDifficult ? 'active' : ''}" on:click={() => handleChange(levels[0])}>
		{levelText['easy']}<img class="bulb" alt="bulb" src="\bulb.png"/></button>

		<button class="category {levels[1] === selectedDifficult ? 'active' : ''}" on:click={() => handleChange(levels[1])}>
		{levelText['medium']}<img class="bulb" alt="bulb" src="\bulb.png"/><img class="bulb" alt="bulb" src="\bulb.png"/></button>

		<button class="category {levels[2] === selectedDifficult ? 'active' : ''}" on:click={() => handleChange(levels[2])}>
		{levelText['hard']}<img class="bulb" alt="bulb" src="\bulb.png"/><img class="bulb" alt="bulb" src="\bulb.png"/><img class="bulb" alt="bulb" src="\bulb.png"/></button>
	
	</div>
	<button class="manual button" on:click={goToManual}>Anleitung</button>
</main>

<style>
@media (min-width: 1920px){
	main{
	   	background-color: black;
		width: 100%;
		height: 100%;
		position: absolute;
		overflow: auto;
		z-index: 1;
    }
	.header {
		background-color: #f8e1e7;
		width: 100%;
		height: 50px;
		position: fixed;
		z-index: 2;
	}
	img {
    height: 50px;
    width: auto;
}
	:global(.back){
		height: 45px;
		width: 45px;
		background-color: #65444e;
		color: white;
		font-size: 20px;
		border: none;
		border-radius: 0.1em;
		margin-top: 5%;
		margin-left: 40px;
	}
  	.container {
		display: grid;
		max-width: 548px;
		margin: auto;
		margin-bottom: 3%;
		margin-top: -35px;
		height: 548px;
		grid-template-rows: auto auto auto;
		row-gap: 25px;
	}
	.bulb {
		width: 55px;
		height: 60px;
		float: right;
		padding-right: 10px;
	}
	.category {
		background-color: black;
		text-align: left;
		padding-left: 40px;
		color: white;
		font-size: 50px;
		font-family:  Calibri;
		font-weight: 10;
		border: 3px solid white;
		cursor: pointer;
	}
	.category:hover {
		background-color: #c27c90;
	}
	.category:active {
		background-color: #b6637a;
		transform: translateY(4px);
	}
	.button {
		color: green;
		text-align: center;
		font-size: 18px;
		font-family:  Calibri;
		font-weight: 10;
		letter-spacing: 0.03em;
		border: none;
		border-radius: 0.1em;
		height: 50px;
		width: 190px;
		cursor: pointer;
		display: block;
		margin-right: auto;
		margin-bottom: 15px;
		margin-left: auto;
	}
}


@media (min-width:2000px){
	main{
	   	background-color: black;
		width: 100%;
		height: 100%;
		position: absolute;
		overflow: auto;
		z-index: 1;
    }
	:global(.back){
		height: 45px;
		width: 45px;
		background-color: #65444e;
		color: white;
		font-size: 20px;
		border: none;
		border-radius: 0.1em;
		margin-top: 5%;
		margin-left: 40px;
	}
  	.container {
		display: grid;
		max-width: 900px;
		margin: auto;
		margin-top: 35px;
		margin-bottom:3%;
		height: 800px;
		grid-template-rows: auto auto auto;
		row-gap: 25px;
	}
	.bulb {
		width: 110px;
		height: 120px;
		float: right;
		padding-right: 10px;
	}
	.category {
		background-color: black;
		text-align: left;
		padding-left: 40px;
		color: white;
		font-size: 90px;
		font-family:  Calibri;
		font-weight: 10;
		border: 3px solid white;
		cursor: pointer;
	}
	.category:hover {
		background-color: #c27c90;
	}
	.category:active {
		background-color: #b6637a;
		transform: translateY(4px);
	}
.button {
		color: yellow;
		text-align: center;
		font-size: 70px;
		font-family:  Calibri;
		font-weight: 10;
		letter-spacing: 0.03em;
		border: none;
		border-radius: 0.1em;
		height: 90px;
		width: 350px;
		cursor: pointer;
		display: block;
		margin-right: auto;
		margin-left: auto;
		
	}
	img {
    height:100px;
    width:auto;
}
.header {
	background-color: #f8e1e7;
    width: 100%;
	height: 100px;
}
}
</style>