import { D as writable, E as identity, F as assign, G as now, H as loop, S as SvelteComponentDev, i as init, d as dispatch_dev, s as safe_not_equal, w as validate_each_argument, I as validate_store, J as component_subscribe, K as set_store_value, v as validate_slots, e as element, a as space, c as claim_element, b as children, g as claim_space, f as detach_dev, j as attr_dev, k as add_location, l as insert_dev, m as append_dev, L as transition_in, M as transition_out, N as check_outros, z as destroy_each, t as text, h as claim_text, r as run_all, n as listen_dev, x as set_data_dev, O as create_component, P as claim_component, Q as mount_component, R as destroy_component, T as group_outros } from './client.138e29e1.js';
import Category from './category.c51bb025.js';
import Cell from './cell.7f758935.js';

const blocks2 = [Array(2).fill([1, 1, 2, 2]), Array(2).fill([3, 3, 4, 4])].flat(
    2
  );
  
  const blocks3 = [
    Array(3).fill([1, 1, 1, 2, 2, 2, 3, 3, 3]),
    Array(3).fill([4, 4, 4, 5, 5, 5, 6, 6, 6]),
    Array(3).fill([7, 7, 7, 8, 8, 8, 9, 9, 9])
  ].flat(2);
  
  const generateGrid = (blockSize = 3) => {
    const elements = blockSize === 3 ? 81 : 16;
    return Array(elements).fill(0)
  };
  
  const shuffle = a => {
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1))
      ;[a[i], a[j]] = [a[j], a[i]];
    }
    return a
  };
  
  const fillGrid = (grid, blockSize = 3) => {
    const gridSize = blockSize === 3 ? 9 : 4;
  
    const stack = [];
    let currentIndex = 0;
    let currentValue = grid[currentIndex];
  
    let numbers = shuffle([1, 2, 3, 4, 5, 6, 7, 8, 9]);
    let numberIndex = 0;
  
    while (hasZeros(grid)) {
      if (currentValue === 0) {
        if (
          isLegal(grid, currentIndex, numbers[numberIndex], blockSize) &&
          numberIndex < gridSize
        ) {
          grid[currentIndex] = numbers[numberIndex];
          stack.push(currentIndex);
          numbers = shuffle([1, 2, 3, 4, 5, 6, 7, 8, 9]);
          numberIndex = -1;
          currentIndex = currentIndex + 1;
          currentValue = grid[currentIndex];
        } else if (numberIndex > gridSize - 1) {
          grid[currentIndex] = 0;
          currentIndex = stack.pop();
          numberIndex = numbers.indexOf(grid[currentIndex]);
          grid[currentIndex] = 0;
        }
      } else {
        currentIndex = currentIndex + 1;
        currentValue = grid[currentIndex];
        numbers = shuffle([1, 2, 3, 4, 5, 6, 7, 8, 9]);
        numberIndex = -1;
      }
      numberIndex = numberIndex + 1;
    }
    return grid
  };
  
  const includeBlockInfo = (grid, blockSize = 3) => {
    const blocks = blockSize === 3 ? blocks3 : blocks2;
  
    return grid.map((cell, index) => ({
      value: cell,
      block: blocks[index],
      position: index,
      readonly: !!cell,
      pencil: new Set()
    }))
  };
  
  const groupByBlock = grid => {
    return grid.reduce((acc, cell) => {
      // The blocks starts at 1
      const block = cell.block - 1;
  
      if (acc[block]) {
        acc[block].push(cell);
      } else {
        acc[block] = [cell];
      }
      return acc
    }, [])
  };
  

  // Number of fiedls already defined
  const numberOfCells = {
    easy: 62,
    medium: 53,
    hard: 44,
  };

  // macht für jede Zelle n Idex????????????????????????????????????????????????????????
  const applyGameDifficult = (difficult, grid) => {
    const indexes = new Set();
    // Set objects are collections of values. A value in a Set may only occur once (is unique in the Set's collection)
    while (indexes.size !== 81 - numberOfCells[difficult]) {
      const randomIndex = Math.floor(Math.random() * 81);
      // Math.floor() returns the largest integer less than or equal to a given number
      // given number: Math.random() returns a floating-point pseudorandom number in the range 0 to less than 1
      indexes.add(randomIndex);
    }
    for (const index of indexes) {
      grid[index] = null;
    }
    return grid
  };
  
  const isLegal = (grid, position, number, blockSize = 3) => {
    const usedNumbers = new Set();
  
    const gridSize = blockSize === 3 ? 9 : 4;
    const blocks = blockSize === 3 ? blocks3 : blocks2;
  
    // Row
    const row = Math.floor(position / gridSize);
    grid.forEach((cell, index) => {
      if (Math.floor(index / gridSize) === row) {
        usedNumbers.add(cell);
      }
    });
  
    // Column
    const column = position % gridSize;
    grid.forEach((cell, index) => {
      if (Math.floor(index % gridSize) === column) {
        usedNumbers.add(cell);
      }
    });
  
    // Block
    const block = blocks[position];
    grid.forEach((cell, index) => {
      if (blocks[index] === block) {
        usedNumbers.add(cell);
      }
    });
  
    return !usedNumbers.has(number)
  };
  
  const hasZeros = grid => {
    return grid.filter(item => item === 0).length !== 0
  };
  
  const getAvailableNumber = (restrictions, blockSize = 3) => {
    const gridSize = blockSize === 3 ? 9 : 4;
    let value = null;
  
    while (!value) {
      const number = Math.floor(Math.random() * gridSize) + 1;
      if (!restrictions.has(number)) {
        value = number;
      }
    }
    return value
  };
  
  const getErrors = grid => {
    return grid.filter(cell => cell.error).length
  };
  
  const getMissingValues = (grid, errors) => {
    return grid.filter(cell => cell.value === null).length + errors
  };
  
  const validateKeyInteraction = (key, position) => {
    const value = parseInt(key, 10);
  
    if (key === 'ArrowDown' && position < 72) {
      return [true, 'down']
    } else if (key === 'ArrowUp' && position > 8) {
      return [true, 'up']
    } else if (key === 'ArrowLeft' && position % 9 > 0) {
      return [true, 'left']
    } else if (key === 'ArrowRight' && position % 9 < 8) {
      return [true, 'right']
    } else if (Number.isInteger(value)) {
      return [true, 'digit']
    }
  
    return [false, null]
  };
  
  const getNewActivePosition = (position, action) => {
    if (action === 'down') {
      return position + 9
    } else if (action === 'up') {
      return position - 9
    } else if (action === 'left') {
      return position - 1
    } else if (action === 'right') {
      return position + 1
    }
  };

var utils = /*#__PURE__*/Object.freeze({
  __proto__: null,
  generateGrid: generateGrid,
  fillGrid: fillGrid,
  includeBlockInfo: includeBlockInfo,
  groupByBlock: groupByBlock,
  applyGameDifficult: applyGameDifficult,
  isLegal: isLegal,
  hasZeros: hasZeros,
  getAvailableNumber: getAvailableNumber,
  getErrors: getErrors,
  getMissingValues: getMissingValues,
  validateKeyInteraction: validateKeyInteraction,
  getNewActivePosition: getNewActivePosition
});

function is_date(obj) {
    return Object.prototype.toString.call(obj) === '[object Date]';
}

function get_interpolator(a, b) {
    if (a === b || a !== a)
        return () => a;
    const type = typeof a;
    if (type !== typeof b || Array.isArray(a) !== Array.isArray(b)) {
        throw new Error('Cannot interpolate values of different type');
    }
    if (Array.isArray(a)) {
        const arr = b.map((bi, i) => {
            return get_interpolator(a[i], bi);
        });
        return t => arr.map(fn => fn(t));
    }
    if (type === 'object') {
        if (!a || !b)
            throw new Error('Object cannot be null');
        if (is_date(a) && is_date(b)) {
            a = a.getTime();
            b = b.getTime();
            const delta = b - a;
            return t => new Date(a + t * delta);
        }
        const keys = Object.keys(b);
        const interpolators = {};
        keys.forEach(key => {
            interpolators[key] = get_interpolator(a[key], b[key]);
        });
        return t => {
            const result = {};
            keys.forEach(key => {
                result[key] = interpolators[key](t);
            });
            return result;
        };
    }
    if (type === 'number') {
        const delta = b - a;
        return t => a + t * delta;
    }
    throw new Error(`Cannot interpolate ${type} values`);
}
function tweened(value, defaults = {}) {
    const store = writable(value);
    let task;
    let target_value = value;
    function set(new_value, opts) {
        if (value == null) {
            store.set(value = new_value);
            return Promise.resolve();
        }
        target_value = new_value;
        let previous_task = task;
        let started = false;
        let { delay = 0, duration = 400, easing = identity, interpolate = get_interpolator } = assign(assign({}, defaults), opts);
        if (duration === 0) {
            if (previous_task) {
                previous_task.abort();
                previous_task = null;
            }
            store.set(value = target_value);
            return Promise.resolve();
        }
        const start = now() + delay;
        let fn;
        task = loop(now => {
            if (now < start)
                return true;
            if (!started) {
                fn = interpolate(value, new_value);
                if (typeof duration === 'function')
                    duration = duration(value, new_value);
                started = true;
            }
            if (previous_task) {
                previous_task.abort();
                previous_task = null;
            }
            const elapsed = now - start;
            if (elapsed > duration) {
                store.set(value = new_value);
                return false;
            }
            // @ts-ignore
            store.set(value = fn(easing(elapsed / duration)));
            return true;
        });
        return task.promise;
    }
    return {
        set,
        update: (fn, opts) => set(fn(target_value, value), opts),
        subscribe: store.subscribe
    };
}

/* src\routes\play.svelte generated by Svelte v3.22.3 */
const file = "src\\routes\\play.svelte";

function get_each_context_1(ctx, list, i) {
	const child_ctx = ctx.slice();
	child_ctx[24] = list[i];
	return child_ctx;
}

function get_each_context(ctx, list, i) {
	const child_ctx = ctx.slice();
	child_ctx[21] = list[i];
	return child_ctx;
}

// (177:10) {#each block as cell}
function create_each_block_1(ctx) {
	let div;
	let current;

	const cell = new Cell({
			props: {
				cell: /*cell*/ ctx[24],
				activePosition: /*activePosition*/ ctx[0],
				highlightValue: /*highlightValue*/ ctx[1]
			},
			$$inline: true
		});

	cell.$on("change-navigation", /*handleChangeNavigation*/ ctx[8]);
	cell.$on("highlight", /*handleHighlight*/ ctx[9]);
	cell.$on("pen", /*handlePen*/ ctx[6]);
	cell.$on("pencil", /*handlePencil*/ ctx[7]);

	const block = {
		c: function create() {
			div = element("div");
			create_component(cell.$$.fragment);
			this.h();
		},
		l: function claim(nodes) {
			div = claim_element(nodes, "DIV", { class: true });
			var div_nodes = children(div);
			claim_component(cell.$$.fragment, div_nodes);
			div_nodes.forEach(detach_dev);
			this.h();
		},
		h: function hydrate() {
			attr_dev(div, "class", "cell svelte-1o7p47u");
			add_location(div, file, 177, 12, 4329);
		},
		m: function mount(target, anchor) {
			insert_dev(target, div, anchor);
			mount_component(cell, div, null);
			current = true;
		},
		p: function update(ctx, dirty) {
			const cell_changes = {};
			if (dirty & /*groupedGrid*/ 16) cell_changes.cell = /*cell*/ ctx[24];
			if (dirty & /*activePosition*/ 1) cell_changes.activePosition = /*activePosition*/ ctx[0];
			if (dirty & /*highlightValue*/ 2) cell_changes.highlightValue = /*highlightValue*/ ctx[1];
			cell.$set(cell_changes);
		},
		i: function intro(local) {
			if (current) return;
			transition_in(cell.$$.fragment, local);
			current = true;
		},
		o: function outro(local) {
			transition_out(cell.$$.fragment, local);
			current = false;
		},
		d: function destroy(detaching) {
			if (detaching) detach_dev(div);
			destroy_component(cell);
		}
	};

	dispatch_dev("SvelteRegisterBlock", {
		block,
		id: create_each_block_1.name,
		type: "each",
		source: "(177:10) {#each block as cell}",
		ctx
	});

	return block;
}

// (175:6) {#each groupedGrid as block}
function create_each_block(ctx) {
	let div;
	let t;
	let current;
	let each_value_1 = /*block*/ ctx[21];
	validate_each_argument(each_value_1);
	let each_blocks = [];

	for (let i = 0; i < each_value_1.length; i += 1) {
		each_blocks[i] = create_each_block_1(get_each_context_1(ctx, each_value_1, i));
	}

	const out = i => transition_out(each_blocks[i], 1, 1, () => {
		each_blocks[i] = null;
	});

	const block = {
		c: function create() {
			div = element("div");

			for (let i = 0; i < each_blocks.length; i += 1) {
				each_blocks[i].c();
			}

			t = space();
			this.h();
		},
		l: function claim(nodes) {
			div = claim_element(nodes, "DIV", { class: true });
			var div_nodes = children(div);

			for (let i = 0; i < each_blocks.length; i += 1) {
				each_blocks[i].l(div_nodes);
			}

			t = claim_space(div_nodes);
			div_nodes.forEach(detach_dev);
			this.h();
		},
		h: function hydrate() {
			attr_dev(div, "class", "block svelte-1o7p47u");
			add_location(div, file, 175, 8, 4263);
		},
		m: function mount(target, anchor) {
			insert_dev(target, div, anchor);

			for (let i = 0; i < each_blocks.length; i += 1) {
				each_blocks[i].m(div, null);
			}

			append_dev(div, t);
			current = true;
		},
		p: function update(ctx, dirty) {
			if (dirty & /*groupedGrid, activePosition, highlightValue, handleChangeNavigation, handleHighlight, handlePen, handlePencil*/ 979) {
				each_value_1 = /*block*/ ctx[21];
				validate_each_argument(each_value_1);
				let i;

				for (i = 0; i < each_value_1.length; i += 1) {
					const child_ctx = get_each_context_1(ctx, each_value_1, i);

					if (each_blocks[i]) {
						each_blocks[i].p(child_ctx, dirty);
						transition_in(each_blocks[i], 1);
					} else {
						each_blocks[i] = create_each_block_1(child_ctx);
						each_blocks[i].c();
						transition_in(each_blocks[i], 1);
						each_blocks[i].m(div, t);
					}
				}

				group_outros();

				for (i = each_value_1.length; i < each_blocks.length; i += 1) {
					out(i);
				}

				check_outros();
			}
		},
		i: function intro(local) {
			if (current) return;

			for (let i = 0; i < each_value_1.length; i += 1) {
				transition_in(each_blocks[i]);
			}

			current = true;
		},
		o: function outro(local) {
			each_blocks = each_blocks.filter(Boolean);

			for (let i = 0; i < each_blocks.length; i += 1) {
				transition_out(each_blocks[i]);
			}

			current = false;
		},
		d: function destroy(detaching) {
			if (detaching) detach_dev(div);
			destroy_each(each_blocks, detaching);
		}
	};

	dispatch_dev("SvelteRegisterBlock", {
		block,
		id: create_each_block.name,
		type: "each",
		source: "(175:6) {#each groupedGrid as block}",
		ctx
	});

	return block;
}

function create_fragment(ctx) {
	let header;
	let div0;
	let img;
	let img_src_value;
	let t0;
	let main;
	let button0;
	let t1;
	let t2;
	let button1;
	let t3;
	let t4;
	let div5;
	let div1;
	let t5;
	let div4;
	let div2;
	let t6;
	let div3;
	let t7;
	let t8;
	let t9;
	let button2;
	let t10;
	let t11;
	let button3;
	let t12;
	let t13;
	let button4;
	let t14;
	let t15;
	let button5;
	let t16;
	let t17;
	let current;
	let dispose;
	let each_value = /*groupedGrid*/ ctx[4];
	validate_each_argument(each_value);
	let each_blocks = [];

	for (let i = 0; i < each_value.length; i += 1) {
		each_blocks[i] = create_each_block(get_each_context(ctx, each_value, i));
	}

	const out = i => transition_out(each_blocks[i], 1, 1, () => {
		each_blocks[i] = null;
	});

	const block = {
		c: function create() {
			header = element("header");
			div0 = element("div");
			img = element("img");
			t0 = space();
			main = element("main");
			button0 = element("button");
			t1 = text("↩");
			t2 = space();
			button1 = element("button");
			t3 = text("i");
			t4 = space();
			div5 = element("div");
			div1 = element("div");

			for (let i = 0; i < each_blocks.length; i += 1) {
				each_blocks[i].c();
			}

			t5 = space();
			div4 = element("div");
			div2 = element("div");
			t6 = space();
			div3 = element("div");
			t7 = text(/*minutes*/ ctx[2]);
			t8 = text(":");
			t9 = text(/*seconds*/ ctx[3]);
			button2 = element("button");
			t10 = text("||");
			t11 = space();
			button3 = element("button");
			t12 = text("Überprüfen");
			t13 = space();
			button4 = element("button");
			t14 = text("Hinweise");
			t15 = space();
			button5 = element("button");
			t16 = text("Neu starten");
			t17 = text(" -->");
			this.h();
		},
		l: function claim(nodes) {
			header = claim_element(nodes, "HEADER", {});
			var header_nodes = children(header);
			div0 = claim_element(header_nodes, "DIV", { class: true });
			var div0_nodes = children(div0);

			img = claim_element(div0_nodes, "IMG", {
				src: true,
				alt: true,
				height: true,
				width: true,
				class: true
			});

			div0_nodes.forEach(detach_dev);
			header_nodes.forEach(detach_dev);
			t0 = claim_space(nodes);
			main = claim_element(nodes, "MAIN", {});
			var main_nodes = children(main);
			button0 = claim_element(main_nodes, "BUTTON", { name: true, class: true });
			var button0_nodes = children(button0);
			t1 = claim_text(button0_nodes, "↩");
			button0_nodes.forEach(detach_dev);
			t2 = claim_space(main_nodes);
			button1 = claim_element(main_nodes, "BUTTON", { name: true, class: true });
			var button1_nodes = children(button1);
			t3 = claim_text(button1_nodes, "i");
			button1_nodes.forEach(detach_dev);
			t4 = claim_space(main_nodes);
			div5 = claim_element(main_nodes, "DIV", { class: true });
			var div5_nodes = children(div5);
			div1 = claim_element(div5_nodes, "DIV", { class: true });
			var div1_nodes = children(div1);

			for (let i = 0; i < each_blocks.length; i += 1) {
				each_blocks[i].l(div1_nodes);
			}

			div1_nodes.forEach(detach_dev);
			t5 = claim_space(div5_nodes);
			div4 = claim_element(div5_nodes, "DIV", { class: true });
			var div4_nodes = children(div4);
			div2 = claim_element(div4_nodes, "DIV", {});
			children(div2).forEach(detach_dev);
			t6 = claim_space(div4_nodes);
			div3 = claim_element(div4_nodes, "DIV", { class: true });
			var div3_nodes = children(div3);
			t7 = claim_text(div3_nodes, /*minutes*/ ctx[2]);
			t8 = claim_text(div3_nodes, ":");
			t9 = claim_text(div3_nodes, /*seconds*/ ctx[3]);
			button2 = claim_element(div3_nodes, "BUTTON", { id: true, class: true });
			var button2_nodes = children(button2);
			t10 = claim_text(button2_nodes, "||");
			button2_nodes.forEach(detach_dev);
			div3_nodes.forEach(detach_dev);
			t11 = claim_space(div4_nodes);
			button3 = claim_element(div4_nodes, "BUTTON", { class: true, id: true });
			var button3_nodes = children(button3);
			t12 = claim_text(button3_nodes, "Überprüfen");
			button3_nodes.forEach(detach_dev);
			t13 = claim_space(div4_nodes);
			button4 = claim_element(div4_nodes, "BUTTON", { class: true, id: true });
			var button4_nodes = children(button4);
			t14 = claim_text(button4_nodes, "Hinweise");
			button4_nodes.forEach(detach_dev);
			t15 = claim_space(div4_nodes);
			button5 = claim_element(div4_nodes, "BUTTON", { class: true, id: true });
			var button5_nodes = children(button5);
			t16 = claim_text(button5_nodes, "Neu starten");
			button5_nodes.forEach(detach_dev);
			div4_nodes.forEach(detach_dev);
			div5_nodes.forEach(detach_dev);
			main_nodes.forEach(detach_dev);
			t17 = claim_text(nodes, " -->");
			this.h();
		},
		h: function hydrate() {
			if (img.src !== (img_src_value = "favicon.png")) attr_dev(img, "src", img_src_value);
			attr_dev(img, "alt", "logo");
			attr_dev(img, "height", "50px");
			attr_dev(img, "width", "auto");
			attr_dev(img, "class", "svelte-1o7p47u");
			add_location(img, file, 164, 21, 3916);
			attr_dev(div0, "class", "header svelte-1o7p47u");
			add_location(div0, file, 164, 1, 3896);
			add_location(header, file, 163, 0, 3885);
			attr_dev(button0, "name", "back");
			attr_dev(button0, "class", "back manual");
			add_location(button0, file, 168, 2, 4010);
			attr_dev(button1, "name", "info");
			attr_dev(button1, "class", "info svelte-1o7p47u");
			add_location(button1, file, 169, 2, 4095);
			attr_dev(div1, "class", "grid svelte-1o7p47u");
			add_location(div1, file, 173, 4, 4199);
			add_location(div2, file, 192, 6, 4769);
			attr_dev(button2, "id", "pause");
			attr_dev(button2, "class", "pause svelte-1o7p47u");
			add_location(button2, file, 193, 46, 4828);
			attr_dev(div3, "class", "timer svelte-1o7p47u");
			add_location(div3, file, 193, 8, 4790);
			attr_dev(button3, "class", "button svelte-1o7p47u");
			attr_dev(button3, "id", "check");
			add_location(button3, file, 194, 8, 4905);
			attr_dev(button4, "class", "button svelte-1o7p47u");
			attr_dev(button4, "id", "tip");
			add_location(button4, file, 195, 8, 4985);
			attr_dev(button5, "class", "button svelte-1o7p47u");
			attr_dev(button5, "id", "restart");
			add_location(button5, file, 196, 8, 5059);
			attr_dev(div4, "class", "menue svelte-1o7p47u");
			add_location(div4, file, 191, 6, 4742);
			attr_dev(div5, "class", "container svelte-1o7p47u");
			add_location(div5, file, 171, 2, 4166);
			add_location(main, file, 167, 0, 4000);
		},
		m: function mount(target, anchor, remount) {
			insert_dev(target, header, anchor);
			append_dev(header, div0);
			append_dev(div0, img);
			insert_dev(target, t0, anchor);
			insert_dev(target, main, anchor);
			append_dev(main, button0);
			append_dev(button0, t1);
			append_dev(main, t2);
			append_dev(main, button1);
			append_dev(button1, t3);
			append_dev(main, t4);
			append_dev(main, div5);
			append_dev(div5, div1);

			for (let i = 0; i < each_blocks.length; i += 1) {
				each_blocks[i].m(div1, null);
			}

			append_dev(div5, t5);
			append_dev(div5, div4);
			append_dev(div4, div2);
			append_dev(div4, t6);
			append_dev(div4, div3);
			append_dev(div3, t7);
			append_dev(div3, t8);
			append_dev(div3, t9);
			append_dev(div3, button2);
			append_dev(button2, t10);
			append_dev(div4, t11);
			append_dev(div4, button3);
			append_dev(button3, t12);
			append_dev(div4, t13);
			append_dev(div4, button4);
			append_dev(button4, t14);
			append_dev(div4, t15);
			append_dev(div4, button5);
			append_dev(button5, t16);
			insert_dev(target, t17, anchor);
			current = true;
			if (remount) run_all(dispose);

			dispose = [
				listen_dev(button0, "click", goToCategories, false, false, false),
				listen_dev(button1, "click", goToManual, false, false, false),
				listen_dev(button2, "click", pause, false, false, false),
				listen_dev(button3, "click", check, false, false, false),
				listen_dev(button4, "click", tip, false, false, false),
				listen_dev(button5, "click", restart, false, false, false)
			];
		},
		p: function update(ctx, [dirty]) {
			if (dirty & /*groupedGrid, activePosition, highlightValue, handleChangeNavigation, handleHighlight, handlePen, handlePencil*/ 979) {
				each_value = /*groupedGrid*/ ctx[4];
				validate_each_argument(each_value);
				let i;

				for (i = 0; i < each_value.length; i += 1) {
					const child_ctx = get_each_context(ctx, each_value, i);

					if (each_blocks[i]) {
						each_blocks[i].p(child_ctx, dirty);
						transition_in(each_blocks[i], 1);
					} else {
						each_blocks[i] = create_each_block(child_ctx);
						each_blocks[i].c();
						transition_in(each_blocks[i], 1);
						each_blocks[i].m(div1, null);
					}
				}

				group_outros();

				for (i = each_value.length; i < each_blocks.length; i += 1) {
					out(i);
				}

				check_outros();
			}

			if (!current || dirty & /*minutes*/ 4) set_data_dev(t7, /*minutes*/ ctx[2]);
			if (!current || dirty & /*seconds*/ 8) set_data_dev(t9, /*seconds*/ ctx[3]);
		},
		i: function intro(local) {
			if (current) return;

			for (let i = 0; i < each_value.length; i += 1) {
				transition_in(each_blocks[i]);
			}

			current = true;
		},
		o: function outro(local) {
			each_blocks = each_blocks.filter(Boolean);

			for (let i = 0; i < each_blocks.length; i += 1) {
				transition_out(each_blocks[i]);
			}

			current = false;
		},
		d: function destroy(detaching) {
			if (detaching) detach_dev(header);
			if (detaching) detach_dev(t0);
			if (detaching) detach_dev(main);
			destroy_each(each_blocks, detaching);
			if (detaching) detach_dev(t17);
			run_all(dispose);
		}
	};

	dispatch_dev("SvelteRegisterBlock", {
		block,
		id: create_fragment.name,
		type: "component",
		source: "",
		ctx
	});

	return block;
}

function formatValue(val) {
	var valString = val + "";

	if (valString.length < 2) {
		return "0" + valString;
	} else {
		return valString;
	}
}

function changeIcon() {
	let x = document.getElementById("pause");

	if (x.innerHTML === "||") {
		x.innerHTML = "&#x25BA";
		stopTimer();
	} else {
		x.innerHTML = "||";
	}
}

function check() {
	
}

function restart() {
	location.reload();
}

function stopTimer(e) {
	e.preventDefault();
	isPaused = true;
}

function pause() {
	changeIcon();
	stopTimer();
}

function goToCategories() {
	window.location.href = "/category";
}

function goToManual() {
	window.location.href = "/manual";
}

function instance($$self, $$props, $$invalidate) {
	let $timer;
	let url = window.location.search;
	let selectedDifficult = url.replace("?difficult=", "");

	//Timer
	let value = 0;

	let timer = tweened(value);
	validate_store(timer, "timer");
	component_subscribe($$self, timer, value => $$invalidate(12, $timer = value));

	setInterval(
		() => {
			set_store_value(timer, $timer++, $timer);
		},
		1000
	);

	let gridWithDifficult;
	let gridWithBlockInfo;
	let activePosition = 0;
	let highlightValue = null;

	const startGame = difficult => {
		const grid = generateGrid(3);
		const filledGrid = fillGrid(grid, 3);
		gridWithDifficult = applyGameDifficult(selectedDifficult, filledGrid);
		$$invalidate(11, gridWithBlockInfo = includeBlockInfo(gridWithDifficult, 3));
	};

	const handlePen = ({ detail: { value, position } }) => {
		const isLegal$1 = isLegal(gridWithDifficult, position, value);

		$$invalidate(11, gridWithBlockInfo = gridWithBlockInfo.map(cell => {
			if (cell.position !== position) {
				return cell;
			}

			return {
				...cell,
				value: value !== 0 ? value : null,
				error: value === 0 ? false : !isLegal$1
			};
		}));

		gridWithDifficult[position] = value;
	};

	const handlePencil = ({ detail: { value, position } }) => {
		if (value === 0) return;

		$$invalidate(11, gridWithBlockInfo = gridWithBlockInfo.map(cell => {
			if (cell.position !== position) {
				return cell;
			}

			const isAlreadyThere = cell.pencil.has(value);

			if (isAlreadyThere) {
				cell.pencil.delete(value);
			} else {
				cell.pencil.add(value);
			}

			return cell;
		}));
	};

	const handleChangeNavigation = ({ detail: value }) => {
		$$invalidate(0, activePosition = value);
	};

	const handleHighlight = ({ detail: value }) => {
		if (highlightValue === value) {
			$$invalidate(1, highlightValue = null);
		} else {
			$$invalidate(1, highlightValue = value);
		}
	};

	startGame();

	window.addEventListener("keydown", e => {
		e.preventDefault();
		const { key, ctrlKey } = e;
		const [isValid, action] = validateKeyInteraction(key, activePosition);
		if (!isValid) return;

		if (action !== "digit") {
			$$invalidate(0, activePosition = getNewActivePosition(activePosition, action));
		} else {
			const cell = gridWithBlockInfo[activePosition];
			if (cell.readonly) return;

			const event = {
				detail: {
					value: parseInt(key, 10),
					position: activePosition
				}
			};

			ctrlKey ? handlePencil(event) : handlePen(event);
		}
	});

	const writable_props = [];

	Object.keys($$props).forEach(key => {
		if (!~writable_props.indexOf(key) && key.slice(0, 2) !== "$$") console.warn(`<Play> was created with unknown prop '${key}'`);
	});

	let { $$slots = {}, $$scope } = $$props;
	validate_slots("Play", $$slots, []);

	$$self.$capture_state = () => ({
		Category,
		Cell,
		utils,
		tweened,
		url,
		selectedDifficult,
		value,
		timer,
		formatValue,
		changeIcon,
		check,
		restart,
		stopTimer,
		gridWithDifficult,
		gridWithBlockInfo,
		activePosition,
		highlightValue,
		startGame,
		handlePen,
		handlePencil,
		pause,
		handleChangeNavigation,
		handleHighlight,
		goToCategories,
		goToManual,
		$timer,
		minutes,
		minname,
		seconds,
		groupedGrid,
		errors,
		missingValues,
		isVictory
	});

	$$self.$inject_state = $$props => {
		if ("url" in $$props) url = $$props.url;
		if ("selectedDifficult" in $$props) selectedDifficult = $$props.selectedDifficult;
		if ("value" in $$props) value = $$props.value;
		if ("timer" in $$props) $$invalidate(5, timer = $$props.timer);
		if ("gridWithDifficult" in $$props) gridWithDifficult = $$props.gridWithDifficult;
		if ("gridWithBlockInfo" in $$props) $$invalidate(11, gridWithBlockInfo = $$props.gridWithBlockInfo);
		if ("activePosition" in $$props) $$invalidate(0, activePosition = $$props.activePosition);
		if ("highlightValue" in $$props) $$invalidate(1, highlightValue = $$props.highlightValue);
		if ("minutes" in $$props) $$invalidate(2, minutes = $$props.minutes);
		if ("minname" in $$props) minname = $$props.minname;
		if ("seconds" in $$props) $$invalidate(3, seconds = $$props.seconds);
		if ("groupedGrid" in $$props) $$invalidate(4, groupedGrid = $$props.groupedGrid);
		if ("errors" in $$props) $$invalidate(14, errors = $$props.errors);
		if ("missingValues" in $$props) $$invalidate(15, missingValues = $$props.missingValues);
		if ("isVictory" in $$props) isVictory = $$props.isVictory;
	};

	let minutes;
	let minname;
	let seconds;
	let groupedGrid;
	let errors;
	let missingValues;
	let isVictory;

	if ($$props && "$$inject" in $$props) {
		$$self.$inject_state($$props.$$inject);
	}

	$$self.$$.update = () => {
		if ($$self.$$.dirty & /*$timer*/ 4096) {
			 $$invalidate(2, minutes = formatValue(Math.floor($timer / 60)));
		}

		if ($$self.$$.dirty & /*minutes*/ 4) {
			 minname = minutes > 1 ? "mins" : "min";
		}

		if ($$self.$$.dirty & /*$timer, minutes*/ 4100) {
			 $$invalidate(3, seconds = formatValue(Math.floor($timer - minutes * 60)));
		}

		if ($$self.$$.dirty & /*gridWithBlockInfo*/ 2048) {
			 $$invalidate(4, groupedGrid = groupByBlock(gridWithBlockInfo));
		}

		if ($$self.$$.dirty & /*gridWithBlockInfo*/ 2048) {
			 $$invalidate(14, errors = getErrors(gridWithBlockInfo));
		}

		if ($$self.$$.dirty & /*gridWithBlockInfo, errors*/ 18432) {
			 $$invalidate(15, missingValues = getMissingValues(gridWithBlockInfo, errors));
		}

		if ($$self.$$.dirty & /*missingValues*/ 32768) {
			 isVictory = missingValues === 0;
		}
	};

	return [
		activePosition,
		highlightValue,
		minutes,
		seconds,
		groupedGrid,
		timer,
		handlePen,
		handlePencil,
		handleChangeNavigation,
		handleHighlight
	];
}

class Play extends SvelteComponentDev {
	constructor(options) {
		super(options);
		init(this, options, instance, create_fragment, safe_not_equal, {});

		dispatch_dev("SvelteRegisterComponent", {
			component: this,
			tagName: "Play",
			options,
			id: create_fragment.name
		});
	}
}

export default Play;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGxheS45ZDdiYTc4ZC5qcyIsInNvdXJjZXMiOlsiLi4vLi4vLi4vc3JjL3JvdXRlcy91dGlscy5qcyIsIi4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdmVsdGUvbW90aW9uL2luZGV4Lm1qcyIsIi4uLy4uLy4uL3NyYy9yb3V0ZXMvcGxheS5zdmVsdGUiXSwic291cmNlc0NvbnRlbnQiOlsiY29uc3QgYmxvY2tzMiA9IFtBcnJheSgyKS5maWxsKFsxLCAxLCAyLCAyXSksIEFycmF5KDIpLmZpbGwoWzMsIDMsIDQsIDRdKV0uZmxhdChcclxuICAgIDJcclxuICApXHJcbiAgXHJcbiAgY29uc3QgYmxvY2tzMyA9IFtcclxuICAgIEFycmF5KDMpLmZpbGwoWzEsIDEsIDEsIDIsIDIsIDIsIDMsIDMsIDNdKSxcclxuICAgIEFycmF5KDMpLmZpbGwoWzQsIDQsIDQsIDUsIDUsIDUsIDYsIDYsIDZdKSxcclxuICAgIEFycmF5KDMpLmZpbGwoWzcsIDcsIDcsIDgsIDgsIDgsIDksIDksIDldKVxyXG4gIF0uZmxhdCgyKVxyXG4gIFxyXG4gIGV4cG9ydCBjb25zdCBnZW5lcmF0ZUdyaWQgPSAoYmxvY2tTaXplID0gMykgPT4ge1xyXG4gICAgY29uc3QgZWxlbWVudHMgPSBibG9ja1NpemUgPT09IDMgPyA4MSA6IDE2XHJcbiAgICByZXR1cm4gQXJyYXkoZWxlbWVudHMpLmZpbGwoMClcclxuICB9XHJcbiAgXHJcbiAgY29uc3Qgc2h1ZmZsZSA9IGEgPT4ge1xyXG4gICAgZm9yIChsZXQgaSA9IGEubGVuZ3RoIC0gMTsgaSA+IDA7IGktLSkge1xyXG4gICAgICBjb25zdCBqID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogKGkgKyAxKSlcclxuICAgICAgO1thW2ldLCBhW2pdXSA9IFthW2pdLCBhW2ldXVxyXG4gICAgfVxyXG4gICAgcmV0dXJuIGFcclxuICB9XHJcbiAgXHJcbiAgZXhwb3J0IGNvbnN0IGZpbGxHcmlkID0gKGdyaWQsIGJsb2NrU2l6ZSA9IDMpID0+IHtcclxuICAgIGNvbnN0IGdyaWRTaXplID0gYmxvY2tTaXplID09PSAzID8gOSA6IDRcclxuICBcclxuICAgIGNvbnN0IHN0YWNrID0gW11cclxuICAgIGxldCBjdXJyZW50SW5kZXggPSAwXHJcbiAgICBsZXQgY3VycmVudFZhbHVlID0gZ3JpZFtjdXJyZW50SW5kZXhdXHJcbiAgXHJcbiAgICBsZXQgbnVtYmVycyA9IHNodWZmbGUoWzEsIDIsIDMsIDQsIDUsIDYsIDcsIDgsIDldKVxyXG4gICAgbGV0IG51bWJlckluZGV4ID0gMFxyXG4gIFxyXG4gICAgd2hpbGUgKGhhc1plcm9zKGdyaWQpKSB7XHJcbiAgICAgIGlmIChjdXJyZW50VmFsdWUgPT09IDApIHtcclxuICAgICAgICBpZiAoXHJcbiAgICAgICAgICBpc0xlZ2FsKGdyaWQsIGN1cnJlbnRJbmRleCwgbnVtYmVyc1tudW1iZXJJbmRleF0sIGJsb2NrU2l6ZSkgJiZcclxuICAgICAgICAgIG51bWJlckluZGV4IDwgZ3JpZFNpemVcclxuICAgICAgICApIHtcclxuICAgICAgICAgIGdyaWRbY3VycmVudEluZGV4XSA9IG51bWJlcnNbbnVtYmVySW5kZXhdXHJcbiAgICAgICAgICBzdGFjay5wdXNoKGN1cnJlbnRJbmRleClcclxuICAgICAgICAgIG51bWJlcnMgPSBzaHVmZmxlKFsxLCAyLCAzLCA0LCA1LCA2LCA3LCA4LCA5XSlcclxuICAgICAgICAgIG51bWJlckluZGV4ID0gLTFcclxuICAgICAgICAgIGN1cnJlbnRJbmRleCA9IGN1cnJlbnRJbmRleCArIDFcclxuICAgICAgICAgIGN1cnJlbnRWYWx1ZSA9IGdyaWRbY3VycmVudEluZGV4XVxyXG4gICAgICAgIH0gZWxzZSBpZiAobnVtYmVySW5kZXggPiBncmlkU2l6ZSAtIDEpIHtcclxuICAgICAgICAgIGdyaWRbY3VycmVudEluZGV4XSA9IDBcclxuICAgICAgICAgIGN1cnJlbnRJbmRleCA9IHN0YWNrLnBvcCgpXHJcbiAgICAgICAgICBudW1iZXJJbmRleCA9IG51bWJlcnMuaW5kZXhPZihncmlkW2N1cnJlbnRJbmRleF0pXHJcbiAgICAgICAgICBncmlkW2N1cnJlbnRJbmRleF0gPSAwXHJcbiAgICAgICAgfVxyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGN1cnJlbnRJbmRleCA9IGN1cnJlbnRJbmRleCArIDFcclxuICAgICAgICBjdXJyZW50VmFsdWUgPSBncmlkW2N1cnJlbnRJbmRleF1cclxuICAgICAgICBudW1iZXJzID0gc2h1ZmZsZShbMSwgMiwgMywgNCwgNSwgNiwgNywgOCwgOV0pXHJcbiAgICAgICAgbnVtYmVySW5kZXggPSAtMVxyXG4gICAgICB9XHJcbiAgICAgIG51bWJlckluZGV4ID0gbnVtYmVySW5kZXggKyAxXHJcbiAgICB9XHJcbiAgICByZXR1cm4gZ3JpZFxyXG4gIH1cclxuICBcclxuICBleHBvcnQgY29uc3QgaW5jbHVkZUJsb2NrSW5mbyA9IChncmlkLCBibG9ja1NpemUgPSAzKSA9PiB7XHJcbiAgICBjb25zdCBibG9ja3MgPSBibG9ja1NpemUgPT09IDMgPyBibG9ja3MzIDogYmxvY2tzMlxyXG4gIFxyXG4gICAgcmV0dXJuIGdyaWQubWFwKChjZWxsLCBpbmRleCkgPT4gKHtcclxuICAgICAgdmFsdWU6IGNlbGwsXHJcbiAgICAgIGJsb2NrOiBibG9ja3NbaW5kZXhdLFxyXG4gICAgICBwb3NpdGlvbjogaW5kZXgsXHJcbiAgICAgIHJlYWRvbmx5OiAhIWNlbGwsXHJcbiAgICAgIHBlbmNpbDogbmV3IFNldCgpXHJcbiAgICB9KSlcclxuICB9XHJcbiAgXHJcbiAgZXhwb3J0IGNvbnN0IGdyb3VwQnlCbG9jayA9IGdyaWQgPT4ge1xyXG4gICAgcmV0dXJuIGdyaWQucmVkdWNlKChhY2MsIGNlbGwpID0+IHtcclxuICAgICAgLy8gVGhlIGJsb2NrcyBzdGFydHMgYXQgMVxyXG4gICAgICBjb25zdCBibG9jayA9IGNlbGwuYmxvY2sgLSAxXHJcbiAgXHJcbiAgICAgIGlmIChhY2NbYmxvY2tdKSB7XHJcbiAgICAgICAgYWNjW2Jsb2NrXS5wdXNoKGNlbGwpXHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgYWNjW2Jsb2NrXSA9IFtjZWxsXVxyXG4gICAgICB9XHJcbiAgICAgIHJldHVybiBhY2NcclxuICAgIH0sIFtdKVxyXG4gIH1cclxuICBcclxuXHJcbiAgLy8gTnVtYmVyIG9mIGZpZWRscyBhbHJlYWR5IGRlZmluZWRcclxuICBjb25zdCBudW1iZXJPZkNlbGxzID0ge1xyXG4gICAgZWFzeTogNjIsXHJcbiAgICBtZWRpdW06IDUzLFxyXG4gICAgaGFyZDogNDQsXHJcbiAgfVxyXG5cclxuICAvLyBtYWNodCBmw7xyIGplZGUgWmVsbGUgbiBJZGV4Pz8/Pz8/Pz8/Pz8/Pz8/Pz8/Pz8/Pz8/Pz8/Pz8/Pz8/Pz8/Pz8/Pz8/Pz8/Pz8/Pz8/Pz8/Pz9cclxuICBleHBvcnQgY29uc3QgYXBwbHlHYW1lRGlmZmljdWx0ID0gKGRpZmZpY3VsdCwgZ3JpZCkgPT4ge1xyXG4gICAgY29uc3QgaW5kZXhlcyA9IG5ldyBTZXQoKVxyXG4gICAgLy8gU2V0IG9iamVjdHMgYXJlIGNvbGxlY3Rpb25zIG9mIHZhbHVlcy4gQSB2YWx1ZSBpbiBhIFNldCBtYXkgb25seSBvY2N1ciBvbmNlIChpcyB1bmlxdWUgaW4gdGhlIFNldCdzIGNvbGxlY3Rpb24pXHJcbiAgICB3aGlsZSAoaW5kZXhlcy5zaXplICE9PSA4MSAtIG51bWJlck9mQ2VsbHNbZGlmZmljdWx0XSkge1xyXG4gICAgICBjb25zdCByYW5kb21JbmRleCA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDgxKVxyXG4gICAgICAvLyBNYXRoLmZsb29yKCkgcmV0dXJucyB0aGUgbGFyZ2VzdCBpbnRlZ2VyIGxlc3MgdGhhbiBvciBlcXVhbCB0byBhIGdpdmVuIG51bWJlclxyXG4gICAgICAvLyBnaXZlbiBudW1iZXI6IE1hdGgucmFuZG9tKCkgcmV0dXJucyBhIGZsb2F0aW5nLXBvaW50IHBzZXVkb3JhbmRvbSBudW1iZXIgaW4gdGhlIHJhbmdlIDAgdG8gbGVzcyB0aGFuIDFcclxuICAgICAgaW5kZXhlcy5hZGQocmFuZG9tSW5kZXgpXHJcbiAgICB9XHJcbiAgICBmb3IgKGNvbnN0IGluZGV4IG9mIGluZGV4ZXMpIHtcclxuICAgICAgZ3JpZFtpbmRleF0gPSBudWxsXHJcbiAgICB9XHJcbiAgICByZXR1cm4gZ3JpZFxyXG4gIH1cclxuICBcclxuICBleHBvcnQgY29uc3QgaXNMZWdhbCA9IChncmlkLCBwb3NpdGlvbiwgbnVtYmVyLCBibG9ja1NpemUgPSAzKSA9PiB7XHJcbiAgICBjb25zdCB1c2VkTnVtYmVycyA9IG5ldyBTZXQoKVxyXG4gIFxyXG4gICAgY29uc3QgZ3JpZFNpemUgPSBibG9ja1NpemUgPT09IDMgPyA5IDogNFxyXG4gICAgY29uc3QgYmxvY2tzID0gYmxvY2tTaXplID09PSAzID8gYmxvY2tzMyA6IGJsb2NrczJcclxuICBcclxuICAgIC8vIFJvd1xyXG4gICAgY29uc3Qgcm93ID0gTWF0aC5mbG9vcihwb3NpdGlvbiAvIGdyaWRTaXplKVxyXG4gICAgZ3JpZC5mb3JFYWNoKChjZWxsLCBpbmRleCkgPT4ge1xyXG4gICAgICBpZiAoTWF0aC5mbG9vcihpbmRleCAvIGdyaWRTaXplKSA9PT0gcm93KSB7XHJcbiAgICAgICAgdXNlZE51bWJlcnMuYWRkKGNlbGwpXHJcbiAgICAgIH1cclxuICAgIH0pXHJcbiAgXHJcbiAgICAvLyBDb2x1bW5cclxuICAgIGNvbnN0IGNvbHVtbiA9IHBvc2l0aW9uICUgZ3JpZFNpemVcclxuICAgIGdyaWQuZm9yRWFjaCgoY2VsbCwgaW5kZXgpID0+IHtcclxuICAgICAgaWYgKE1hdGguZmxvb3IoaW5kZXggJSBncmlkU2l6ZSkgPT09IGNvbHVtbikge1xyXG4gICAgICAgIHVzZWROdW1iZXJzLmFkZChjZWxsKVxyXG4gICAgICB9XHJcbiAgICB9KVxyXG4gIFxyXG4gICAgLy8gQmxvY2tcclxuICAgIGNvbnN0IGJsb2NrID0gYmxvY2tzW3Bvc2l0aW9uXVxyXG4gICAgZ3JpZC5mb3JFYWNoKChjZWxsLCBpbmRleCkgPT4ge1xyXG4gICAgICBpZiAoYmxvY2tzW2luZGV4XSA9PT0gYmxvY2spIHtcclxuICAgICAgICB1c2VkTnVtYmVycy5hZGQoY2VsbClcclxuICAgICAgfVxyXG4gICAgfSlcclxuICBcclxuICAgIHJldHVybiAhdXNlZE51bWJlcnMuaGFzKG51bWJlcilcclxuICB9XHJcbiAgXHJcbiAgZXhwb3J0IGNvbnN0IGhhc1plcm9zID0gZ3JpZCA9PiB7XHJcbiAgICByZXR1cm4gZ3JpZC5maWx0ZXIoaXRlbSA9PiBpdGVtID09PSAwKS5sZW5ndGggIT09IDBcclxuICB9XHJcbiAgXHJcbiAgZXhwb3J0IGNvbnN0IGdldEF2YWlsYWJsZU51bWJlciA9IChyZXN0cmljdGlvbnMsIGJsb2NrU2l6ZSA9IDMpID0+IHtcclxuICAgIGNvbnN0IGdyaWRTaXplID0gYmxvY2tTaXplID09PSAzID8gOSA6IDRcclxuICAgIGxldCB2YWx1ZSA9IG51bGxcclxuICBcclxuICAgIHdoaWxlICghdmFsdWUpIHtcclxuICAgICAgY29uc3QgbnVtYmVyID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogZ3JpZFNpemUpICsgMVxyXG4gICAgICBpZiAoIXJlc3RyaWN0aW9ucy5oYXMobnVtYmVyKSkge1xyXG4gICAgICAgIHZhbHVlID0gbnVtYmVyXHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIHJldHVybiB2YWx1ZVxyXG4gIH1cclxuICBcclxuICBleHBvcnQgY29uc3QgZ2V0RXJyb3JzID0gZ3JpZCA9PiB7XHJcbiAgICByZXR1cm4gZ3JpZC5maWx0ZXIoY2VsbCA9PiBjZWxsLmVycm9yKS5sZW5ndGhcclxuICB9XHJcbiAgXHJcbiAgZXhwb3J0IGNvbnN0IGdldE1pc3NpbmdWYWx1ZXMgPSAoZ3JpZCwgZXJyb3JzKSA9PiB7XHJcbiAgICByZXR1cm4gZ3JpZC5maWx0ZXIoY2VsbCA9PiBjZWxsLnZhbHVlID09PSBudWxsKS5sZW5ndGggKyBlcnJvcnNcclxuICB9XHJcbiAgXHJcbiAgZXhwb3J0IGNvbnN0IHZhbGlkYXRlS2V5SW50ZXJhY3Rpb24gPSAoa2V5LCBwb3NpdGlvbikgPT4ge1xyXG4gICAgY29uc3QgdmFsdWUgPSBwYXJzZUludChrZXksIDEwKVxyXG4gIFxyXG4gICAgaWYgKGtleSA9PT0gJ0Fycm93RG93bicgJiYgcG9zaXRpb24gPCA3Mikge1xyXG4gICAgICByZXR1cm4gW3RydWUsICdkb3duJ11cclxuICAgIH0gZWxzZSBpZiAoa2V5ID09PSAnQXJyb3dVcCcgJiYgcG9zaXRpb24gPiA4KSB7XHJcbiAgICAgIHJldHVybiBbdHJ1ZSwgJ3VwJ11cclxuICAgIH0gZWxzZSBpZiAoa2V5ID09PSAnQXJyb3dMZWZ0JyAmJiBwb3NpdGlvbiAlIDkgPiAwKSB7XHJcbiAgICAgIHJldHVybiBbdHJ1ZSwgJ2xlZnQnXVxyXG4gICAgfSBlbHNlIGlmIChrZXkgPT09ICdBcnJvd1JpZ2h0JyAmJiBwb3NpdGlvbiAlIDkgPCA4KSB7XHJcbiAgICAgIHJldHVybiBbdHJ1ZSwgJ3JpZ2h0J11cclxuICAgIH0gZWxzZSBpZiAoTnVtYmVyLmlzSW50ZWdlcih2YWx1ZSkpIHtcclxuICAgICAgcmV0dXJuIFt0cnVlLCAnZGlnaXQnXVxyXG4gICAgfVxyXG4gIFxyXG4gICAgcmV0dXJuIFtmYWxzZSwgbnVsbF1cclxuICB9XHJcbiAgXHJcbiAgZXhwb3J0IGNvbnN0IGdldE5ld0FjdGl2ZVBvc2l0aW9uID0gKHBvc2l0aW9uLCBhY3Rpb24pID0+IHtcclxuICAgIGlmIChhY3Rpb24gPT09ICdkb3duJykge1xyXG4gICAgICByZXR1cm4gcG9zaXRpb24gKyA5XHJcbiAgICB9IGVsc2UgaWYgKGFjdGlvbiA9PT0gJ3VwJykge1xyXG4gICAgICByZXR1cm4gcG9zaXRpb24gLSA5XHJcbiAgICB9IGVsc2UgaWYgKGFjdGlvbiA9PT0gJ2xlZnQnKSB7XHJcbiAgICAgIHJldHVybiBwb3NpdGlvbiAtIDFcclxuICAgIH0gZWxzZSBpZiAoYWN0aW9uID09PSAncmlnaHQnKSB7XHJcbiAgICAgIHJldHVybiBwb3NpdGlvbiArIDFcclxuICAgIH1cclxuICB9XHJcbiAgIiwiaW1wb3J0IHsgd3JpdGFibGUgfSBmcm9tICcuLi9zdG9yZSc7XG5pbXBvcnQgeyBub3csIGxvb3AsIGFzc2lnbiB9IGZyb20gJy4uL2ludGVybmFsJztcbmltcG9ydCB7IGxpbmVhciB9IGZyb20gJy4uL2Vhc2luZyc7XG5cbmZ1bmN0aW9uIGlzX2RhdGUob2JqKSB7XG4gICAgcmV0dXJuIE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcuY2FsbChvYmopID09PSAnW29iamVjdCBEYXRlXSc7XG59XG5cbmZ1bmN0aW9uIHRpY2tfc3ByaW5nKGN0eCwgbGFzdF92YWx1ZSwgY3VycmVudF92YWx1ZSwgdGFyZ2V0X3ZhbHVlKSB7XG4gICAgaWYgKHR5cGVvZiBjdXJyZW50X3ZhbHVlID09PSAnbnVtYmVyJyB8fCBpc19kYXRlKGN1cnJlbnRfdmFsdWUpKSB7XG4gICAgICAgIC8vIEB0cy1pZ25vcmVcbiAgICAgICAgY29uc3QgZGVsdGEgPSB0YXJnZXRfdmFsdWUgLSBjdXJyZW50X3ZhbHVlO1xuICAgICAgICAvLyBAdHMtaWdub3JlXG4gICAgICAgIGNvbnN0IHZlbG9jaXR5ID0gKGN1cnJlbnRfdmFsdWUgLSBsYXN0X3ZhbHVlKSAvIChjdHguZHQgfHwgMSAvIDYwKTsgLy8gZ3VhcmQgZGl2IGJ5IDBcbiAgICAgICAgY29uc3Qgc3ByaW5nID0gY3R4Lm9wdHMuc3RpZmZuZXNzICogZGVsdGE7XG4gICAgICAgIGNvbnN0IGRhbXBlciA9IGN0eC5vcHRzLmRhbXBpbmcgKiB2ZWxvY2l0eTtcbiAgICAgICAgY29uc3QgYWNjZWxlcmF0aW9uID0gKHNwcmluZyAtIGRhbXBlcikgKiBjdHguaW52X21hc3M7XG4gICAgICAgIGNvbnN0IGQgPSAodmVsb2NpdHkgKyBhY2NlbGVyYXRpb24pICogY3R4LmR0O1xuICAgICAgICBpZiAoTWF0aC5hYnMoZCkgPCBjdHgub3B0cy5wcmVjaXNpb24gJiYgTWF0aC5hYnMoZGVsdGEpIDwgY3R4Lm9wdHMucHJlY2lzaW9uKSB7XG4gICAgICAgICAgICByZXR1cm4gdGFyZ2V0X3ZhbHVlOyAvLyBzZXR0bGVkXG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBjdHguc2V0dGxlZCA9IGZhbHNlOyAvLyBzaWduYWwgbG9vcCB0byBrZWVwIHRpY2tpbmdcbiAgICAgICAgICAgIC8vIEB0cy1pZ25vcmVcbiAgICAgICAgICAgIHJldHVybiBpc19kYXRlKGN1cnJlbnRfdmFsdWUpID9cbiAgICAgICAgICAgICAgICBuZXcgRGF0ZShjdXJyZW50X3ZhbHVlLmdldFRpbWUoKSArIGQpIDogY3VycmVudF92YWx1ZSArIGQ7XG4gICAgICAgIH1cbiAgICB9XG4gICAgZWxzZSBpZiAoQXJyYXkuaXNBcnJheShjdXJyZW50X3ZhbHVlKSkge1xuICAgICAgICAvLyBAdHMtaWdub3JlXG4gICAgICAgIHJldHVybiBjdXJyZW50X3ZhbHVlLm1hcCgoXywgaSkgPT4gdGlja19zcHJpbmcoY3R4LCBsYXN0X3ZhbHVlW2ldLCBjdXJyZW50X3ZhbHVlW2ldLCB0YXJnZXRfdmFsdWVbaV0pKTtcbiAgICB9XG4gICAgZWxzZSBpZiAodHlwZW9mIGN1cnJlbnRfdmFsdWUgPT09ICdvYmplY3QnKSB7XG4gICAgICAgIGNvbnN0IG5leHRfdmFsdWUgPSB7fTtcbiAgICAgICAgZm9yIChjb25zdCBrIGluIGN1cnJlbnRfdmFsdWUpXG4gICAgICAgICAgICAvLyBAdHMtaWdub3JlXG4gICAgICAgICAgICBuZXh0X3ZhbHVlW2tdID0gdGlja19zcHJpbmcoY3R4LCBsYXN0X3ZhbHVlW2tdLCBjdXJyZW50X3ZhbHVlW2tdLCB0YXJnZXRfdmFsdWVba10pO1xuICAgICAgICAvLyBAdHMtaWdub3JlXG4gICAgICAgIHJldHVybiBuZXh0X3ZhbHVlO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBDYW5ub3Qgc3ByaW5nICR7dHlwZW9mIGN1cnJlbnRfdmFsdWV9IHZhbHVlc2ApO1xuICAgIH1cbn1cbmZ1bmN0aW9uIHNwcmluZyh2YWx1ZSwgb3B0cyA9IHt9KSB7XG4gICAgY29uc3Qgc3RvcmUgPSB3cml0YWJsZSh2YWx1ZSk7XG4gICAgY29uc3QgeyBzdGlmZm5lc3MgPSAwLjE1LCBkYW1waW5nID0gMC44LCBwcmVjaXNpb24gPSAwLjAxIH0gPSBvcHRzO1xuICAgIGxldCBsYXN0X3RpbWU7XG4gICAgbGV0IHRhc2s7XG4gICAgbGV0IGN1cnJlbnRfdG9rZW47XG4gICAgbGV0IGxhc3RfdmFsdWUgPSB2YWx1ZTtcbiAgICBsZXQgdGFyZ2V0X3ZhbHVlID0gdmFsdWU7XG4gICAgbGV0IGludl9tYXNzID0gMTtcbiAgICBsZXQgaW52X21hc3NfcmVjb3ZlcnlfcmF0ZSA9IDA7XG4gICAgbGV0IGNhbmNlbF90YXNrID0gZmFsc2U7XG4gICAgZnVuY3Rpb24gc2V0KG5ld192YWx1ZSwgb3B0cyA9IHt9KSB7XG4gICAgICAgIHRhcmdldF92YWx1ZSA9IG5ld192YWx1ZTtcbiAgICAgICAgY29uc3QgdG9rZW4gPSBjdXJyZW50X3Rva2VuID0ge307XG4gICAgICAgIGlmICh2YWx1ZSA9PSBudWxsIHx8IG9wdHMuaGFyZCB8fCAoc3ByaW5nLnN0aWZmbmVzcyA+PSAxICYmIHNwcmluZy5kYW1waW5nID49IDEpKSB7XG4gICAgICAgICAgICBjYW5jZWxfdGFzayA9IHRydWU7IC8vIGNhbmNlbCBhbnkgcnVubmluZyBhbmltYXRpb25cbiAgICAgICAgICAgIGxhc3RfdGltZSA9IG5vdygpO1xuICAgICAgICAgICAgbGFzdF92YWx1ZSA9IG5ld192YWx1ZTtcbiAgICAgICAgICAgIHN0b3JlLnNldCh2YWx1ZSA9IHRhcmdldF92YWx1ZSk7XG4gICAgICAgICAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKCk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAob3B0cy5zb2Z0KSB7XG4gICAgICAgICAgICBjb25zdCByYXRlID0gb3B0cy5zb2Z0ID09PSB0cnVlID8gLjUgOiArb3B0cy5zb2Z0O1xuICAgICAgICAgICAgaW52X21hc3NfcmVjb3ZlcnlfcmF0ZSA9IDEgLyAocmF0ZSAqIDYwKTtcbiAgICAgICAgICAgIGludl9tYXNzID0gMDsgLy8gaW5maW5pdGUgbWFzcywgdW5hZmZlY3RlZCBieSBzcHJpbmcgZm9yY2VzXG4gICAgICAgIH1cbiAgICAgICAgaWYgKCF0YXNrKSB7XG4gICAgICAgICAgICBsYXN0X3RpbWUgPSBub3coKTtcbiAgICAgICAgICAgIGNhbmNlbF90YXNrID0gZmFsc2U7XG4gICAgICAgICAgICB0YXNrID0gbG9vcChub3cgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChjYW5jZWxfdGFzaykge1xuICAgICAgICAgICAgICAgICAgICBjYW5jZWxfdGFzayA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICB0YXNrID0gbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpbnZfbWFzcyA9IE1hdGgubWluKGludl9tYXNzICsgaW52X21hc3NfcmVjb3ZlcnlfcmF0ZSwgMSk7XG4gICAgICAgICAgICAgICAgY29uc3QgY3R4ID0ge1xuICAgICAgICAgICAgICAgICAgICBpbnZfbWFzcyxcbiAgICAgICAgICAgICAgICAgICAgb3B0czogc3ByaW5nLFxuICAgICAgICAgICAgICAgICAgICBzZXR0bGVkOiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICBkdDogKG5vdyAtIGxhc3RfdGltZSkgKiA2MCAvIDEwMDBcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIGNvbnN0IG5leHRfdmFsdWUgPSB0aWNrX3NwcmluZyhjdHgsIGxhc3RfdmFsdWUsIHZhbHVlLCB0YXJnZXRfdmFsdWUpO1xuICAgICAgICAgICAgICAgIGxhc3RfdGltZSA9IG5vdztcbiAgICAgICAgICAgICAgICBsYXN0X3ZhbHVlID0gdmFsdWU7XG4gICAgICAgICAgICAgICAgc3RvcmUuc2V0KHZhbHVlID0gbmV4dF92YWx1ZSk7XG4gICAgICAgICAgICAgICAgaWYgKGN0eC5zZXR0bGVkKVxuICAgICAgICAgICAgICAgICAgICB0YXNrID0gbnVsbDtcbiAgICAgICAgICAgICAgICByZXR1cm4gIWN0eC5zZXR0bGVkO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKGZ1bGZpbCA9PiB7XG4gICAgICAgICAgICB0YXNrLnByb21pc2UudGhlbigoKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKHRva2VuID09PSBjdXJyZW50X3Rva2VuKVxuICAgICAgICAgICAgICAgICAgICBmdWxmaWwoKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9KTtcbiAgICB9XG4gICAgY29uc3Qgc3ByaW5nID0ge1xuICAgICAgICBzZXQsXG4gICAgICAgIHVwZGF0ZTogKGZuLCBvcHRzKSA9PiBzZXQoZm4odGFyZ2V0X3ZhbHVlLCB2YWx1ZSksIG9wdHMpLFxuICAgICAgICBzdWJzY3JpYmU6IHN0b3JlLnN1YnNjcmliZSxcbiAgICAgICAgc3RpZmZuZXNzLFxuICAgICAgICBkYW1waW5nLFxuICAgICAgICBwcmVjaXNpb25cbiAgICB9O1xuICAgIHJldHVybiBzcHJpbmc7XG59XG5cbmZ1bmN0aW9uIGdldF9pbnRlcnBvbGF0b3IoYSwgYikge1xuICAgIGlmIChhID09PSBiIHx8IGEgIT09IGEpXG4gICAgICAgIHJldHVybiAoKSA9PiBhO1xuICAgIGNvbnN0IHR5cGUgPSB0eXBlb2YgYTtcbiAgICBpZiAodHlwZSAhPT0gdHlwZW9mIGIgfHwgQXJyYXkuaXNBcnJheShhKSAhPT0gQXJyYXkuaXNBcnJheShiKSkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0Nhbm5vdCBpbnRlcnBvbGF0ZSB2YWx1ZXMgb2YgZGlmZmVyZW50IHR5cGUnKTtcbiAgICB9XG4gICAgaWYgKEFycmF5LmlzQXJyYXkoYSkpIHtcbiAgICAgICAgY29uc3QgYXJyID0gYi5tYXAoKGJpLCBpKSA9PiB7XG4gICAgICAgICAgICByZXR1cm4gZ2V0X2ludGVycG9sYXRvcihhW2ldLCBiaSk7XG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gdCA9PiBhcnIubWFwKGZuID0+IGZuKHQpKTtcbiAgICB9XG4gICAgaWYgKHR5cGUgPT09ICdvYmplY3QnKSB7XG4gICAgICAgIGlmICghYSB8fCAhYilcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignT2JqZWN0IGNhbm5vdCBiZSBudWxsJyk7XG4gICAgICAgIGlmIChpc19kYXRlKGEpICYmIGlzX2RhdGUoYikpIHtcbiAgICAgICAgICAgIGEgPSBhLmdldFRpbWUoKTtcbiAgICAgICAgICAgIGIgPSBiLmdldFRpbWUoKTtcbiAgICAgICAgICAgIGNvbnN0IGRlbHRhID0gYiAtIGE7XG4gICAgICAgICAgICByZXR1cm4gdCA9PiBuZXcgRGF0ZShhICsgdCAqIGRlbHRhKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBrZXlzID0gT2JqZWN0LmtleXMoYik7XG4gICAgICAgIGNvbnN0IGludGVycG9sYXRvcnMgPSB7fTtcbiAgICAgICAga2V5cy5mb3JFYWNoKGtleSA9PiB7XG4gICAgICAgICAgICBpbnRlcnBvbGF0b3JzW2tleV0gPSBnZXRfaW50ZXJwb2xhdG9yKGFba2V5XSwgYltrZXldKTtcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiB0ID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHJlc3VsdCA9IHt9O1xuICAgICAgICAgICAga2V5cy5mb3JFYWNoKGtleSA9PiB7XG4gICAgICAgICAgICAgICAgcmVzdWx0W2tleV0gPSBpbnRlcnBvbGF0b3JzW2tleV0odCk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgICAgIH07XG4gICAgfVxuICAgIGlmICh0eXBlID09PSAnbnVtYmVyJykge1xuICAgICAgICBjb25zdCBkZWx0YSA9IGIgLSBhO1xuICAgICAgICByZXR1cm4gdCA9PiBhICsgdCAqIGRlbHRhO1xuICAgIH1cbiAgICB0aHJvdyBuZXcgRXJyb3IoYENhbm5vdCBpbnRlcnBvbGF0ZSAke3R5cGV9IHZhbHVlc2ApO1xufVxuZnVuY3Rpb24gdHdlZW5lZCh2YWx1ZSwgZGVmYXVsdHMgPSB7fSkge1xuICAgIGNvbnN0IHN0b3JlID0gd3JpdGFibGUodmFsdWUpO1xuICAgIGxldCB0YXNrO1xuICAgIGxldCB0YXJnZXRfdmFsdWUgPSB2YWx1ZTtcbiAgICBmdW5jdGlvbiBzZXQobmV3X3ZhbHVlLCBvcHRzKSB7XG4gICAgICAgIGlmICh2YWx1ZSA9PSBudWxsKSB7XG4gICAgICAgICAgICBzdG9yZS5zZXQodmFsdWUgPSBuZXdfdmFsdWUpO1xuICAgICAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSgpO1xuICAgICAgICB9XG4gICAgICAgIHRhcmdldF92YWx1ZSA9IG5ld192YWx1ZTtcbiAgICAgICAgbGV0IHByZXZpb3VzX3Rhc2sgPSB0YXNrO1xuICAgICAgICBsZXQgc3RhcnRlZCA9IGZhbHNlO1xuICAgICAgICBsZXQgeyBkZWxheSA9IDAsIGR1cmF0aW9uID0gNDAwLCBlYXNpbmcgPSBsaW5lYXIsIGludGVycG9sYXRlID0gZ2V0X2ludGVycG9sYXRvciB9ID0gYXNzaWduKGFzc2lnbih7fSwgZGVmYXVsdHMpLCBvcHRzKTtcbiAgICAgICAgaWYgKGR1cmF0aW9uID09PSAwKSB7XG4gICAgICAgICAgICBpZiAocHJldmlvdXNfdGFzaykge1xuICAgICAgICAgICAgICAgIHByZXZpb3VzX3Rhc2suYWJvcnQoKTtcbiAgICAgICAgICAgICAgICBwcmV2aW91c190YXNrID0gbnVsbDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHN0b3JlLnNldCh2YWx1ZSA9IHRhcmdldF92YWx1ZSk7XG4gICAgICAgICAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKCk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3Qgc3RhcnQgPSBub3coKSArIGRlbGF5O1xuICAgICAgICBsZXQgZm47XG4gICAgICAgIHRhc2sgPSBsb29wKG5vdyA9PiB7XG4gICAgICAgICAgICBpZiAobm93IDwgc3RhcnQpXG4gICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgICBpZiAoIXN0YXJ0ZWQpIHtcbiAgICAgICAgICAgICAgICBmbiA9IGludGVycG9sYXRlKHZhbHVlLCBuZXdfdmFsdWUpO1xuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgZHVyYXRpb24gPT09ICdmdW5jdGlvbicpXG4gICAgICAgICAgICAgICAgICAgIGR1cmF0aW9uID0gZHVyYXRpb24odmFsdWUsIG5ld192YWx1ZSk7XG4gICAgICAgICAgICAgICAgc3RhcnRlZCA9IHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAocHJldmlvdXNfdGFzaykge1xuICAgICAgICAgICAgICAgIHByZXZpb3VzX3Rhc2suYWJvcnQoKTtcbiAgICAgICAgICAgICAgICBwcmV2aW91c190YXNrID0gbnVsbDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN0IGVsYXBzZWQgPSBub3cgLSBzdGFydDtcbiAgICAgICAgICAgIGlmIChlbGFwc2VkID4gZHVyYXRpb24pIHtcbiAgICAgICAgICAgICAgICBzdG9yZS5zZXQodmFsdWUgPSBuZXdfdmFsdWUpO1xuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIEB0cy1pZ25vcmVcbiAgICAgICAgICAgIHN0b3JlLnNldCh2YWx1ZSA9IGZuKGVhc2luZyhlbGFwc2VkIC8gZHVyYXRpb24pKSk7XG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiB0YXNrLnByb21pc2U7XG4gICAgfVxuICAgIHJldHVybiB7XG4gICAgICAgIHNldCxcbiAgICAgICAgdXBkYXRlOiAoZm4sIG9wdHMpID0+IHNldChmbih0YXJnZXRfdmFsdWUsIHZhbHVlKSwgb3B0cyksXG4gICAgICAgIHN1YnNjcmliZTogc3RvcmUuc3Vic2NyaWJlXG4gICAgfTtcbn1cblxuZXhwb3J0IHsgc3ByaW5nLCB0d2VlbmVkIH07XG4iLCI8c2NyaXB0PlxyXG4gIGltcG9ydCBDYXRlZ29yeSBmcm9tIFwiLi9jYXRlZ29yeS5zdmVsdGVcIjtcclxuICBpbXBvcnQgQ2VsbCBmcm9tIFwiLi9jZWxsLnN2ZWx0ZVwiO1xyXG4gIGltcG9ydCAqIGFzIHV0aWxzIGZyb20gXCIuL3V0aWxzXCI7XHJcbiAgaW1wb3J0IHsgdHdlZW5lZCB9IGZyb20gJ3N2ZWx0ZS9tb3Rpb24nO1xyXG5cclxuICBsZXQgdXJsID0gd2luZG93LmxvY2F0aW9uLnNlYXJjaDtcclxuICBsZXQgc2VsZWN0ZWREaWZmaWN1bHQgPSB1cmwucmVwbGFjZShcIj9kaWZmaWN1bHQ9XCIsICcnKTtcclxuXHJcbiAgLy9UaW1lclxyXG4gIGxldCB2YWx1ZSA9IDA7XHJcbiAgbGV0IHRpbWVyID0gdHdlZW5lZCh2YWx1ZSk7XHJcbiAgc2V0SW50ZXJ2YWwoKCkgPT4ge1xyXG4gICAgJHRpbWVyKys7XHJcbiAgfSwgMTAwMCk7XHJcblxyXG4gIGZ1bmN0aW9uIGZvcm1hdFZhbHVlKHZhbCkge1xyXG4gICAgdmFyIHZhbFN0cmluZyA9IHZhbCArIFwiXCI7XHJcbiAgICBpZiAodmFsU3RyaW5nLmxlbmd0aCA8IDIpIHtcclxuICAgICAgcmV0dXJuIFwiMFwiICsgdmFsU3RyaW5nO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuIHZhbFN0cmluZztcclxuICAgIH1cclxuICB9XHJcblxyXG4gICQ6IG1pbnV0ZXMgPSBmb3JtYXRWYWx1ZShNYXRoLmZsb29yKCR0aW1lciAvIDYwKSk7XHJcbiAgJDogbWlubmFtZSA9IG1pbnV0ZXMgPiAxID8gXCJtaW5zXCIgOiBcIm1pblwiO1xyXG4gICQ6IHNlY29uZHMgPSBmb3JtYXRWYWx1ZShNYXRoLmZsb29yKCR0aW1lciAtIG1pbnV0ZXMgKiA2MCkpO1xyXG5cclxuICBmdW5jdGlvbiBjaGFuZ2VJY29uKCkge1xyXG4gICAgbGV0IHggPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInBhdXNlXCIpO1xyXG4gICAgaWYgKHguaW5uZXJIVE1MID09PSBcInx8XCIpIHtcclxuICAgICB4LmlubmVySFRNTCA9IFwiJiN4MjVCQVwiO1xyXG4gICAgICAgc3RvcFRpbWVyKCk7ICAgICB9IGVsc2Uge1xyXG4gICAgIHguaW5uZXJIVE1MID0gXCJ8fFwiO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgZnVuY3Rpb24gY2hlY2soKSB7XHJcbiAgICAgXHJcbiAgfVxyXG5cclxuICBmdW5jdGlvbiByZXN0YXJ0KCkge1xyXG4gICAgbG9jYXRpb24ucmVsb2FkKCk7IFxyXG4gIH1cclxuXHJcblxyXG5cclxuXHJcblxyXG5cclxuXHJcbiAgZnVuY3Rpb24gc3RvcFRpbWVyKGUpIHtcclxuICAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICAgaXNQYXVzZWQgPSB0cnVlO1xyXG4gICB9XHJcblxyXG4gXHJcbiAgIGxldCBncmlkV2l0aERpZmZpY3VsdDtcclxuIGxldCBncmlkV2l0aEJsb2NrSW5mbztcclxuICBsZXQgYWN0aXZlUG9zaXRpb24gPSAwO1xyXG4gICBsZXQgaGlnaGxpZ2h0VmFsdWUgPSBudWxsO1xyXG5cclxuICAgY29uc3Qgc3RhcnRHYW1lID0gZGlmZmljdWx0ID0+IHtcclxuICAgY29uc3QgZ3JpZCA9IHV0aWxzLmdlbmVyYXRlR3JpZCgzKTtcclxuICAgIGNvbnN0IGZpbGxlZEdyaWQgPSB1dGlscy5maWxsR3JpZChncmlkLCAzKTtcclxuICAgICBncmlkV2l0aERpZmZpY3VsdCA9IHV0aWxzLmFwcGx5R2FtZURpZmZpY3VsdChzZWxlY3RlZERpZmZpY3VsdCwgZmlsbGVkR3JpZCk7XHJcbiAgIGdyaWRXaXRoQmxvY2tJbmZvID0gdXRpbHMuaW5jbHVkZUJsb2NrSW5mbyhncmlkV2l0aERpZmZpY3VsdCwgMyk7XHJcbiAgIH07XHJcblxyXG4gICBjb25zdCBoYW5kbGVQZW4gPSAoeyBkZXRhaWw6IHsgdmFsdWUsIHBvc2l0aW9uIH0gfSkgPT4ge1xyXG4gICAgIGNvbnN0IGlzTGVnYWwgPSB1dGlscy5pc0xlZ2FsKGdyaWRXaXRoRGlmZmljdWx0LCBwb3NpdGlvbiwgdmFsdWUpO1xyXG4gICAgIGdyaWRXaXRoQmxvY2tJbmZvID0gZ3JpZFdpdGhCbG9ja0luZm8ubWFwKGNlbGwgPT4ge1xyXG4gICAgICBpZiAoY2VsbC5wb3NpdGlvbiAhPT0gcG9zaXRpb24pIHtcclxuICAgICAgICByZXR1cm4gY2VsbDtcclxuICAgICB9XHJcblxyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgICAuLi5jZWxsLFxyXG4gICAgICAgICB2YWx1ZTogdmFsdWUgIT09IDAgPyB2YWx1ZSA6IG51bGwsXHJcbiAgICAgICAgZXJyb3I6IHZhbHVlID09PSAwID8gZmFsc2UgOiAhaXNMZWdhbFxyXG4gICAgICAgfTtcclxuICAgIH0pO1xyXG4gICAgZ3JpZFdpdGhEaWZmaWN1bHRbcG9zaXRpb25dID0gdmFsdWU7XHJcbiAgICAgICB9O1xyXG5cclxuICAgY29uc3QgaGFuZGxlUGVuY2lsID0gKHsgZGV0YWlsOiB7IHZhbHVlLCBwb3NpdGlvbiB9IH0pID0+IHtcclxuICAgICBpZiAodmFsdWUgPT09IDApIHJldHVybjtcclxuXHJcbiAgIGdyaWRXaXRoQmxvY2tJbmZvID0gZ3JpZFdpdGhCbG9ja0luZm8ubWFwKGNlbGwgPT4ge1xyXG4gICAgICBpZiAoY2VsbC5wb3NpdGlvbiAhPT0gcG9zaXRpb24pIHtcclxuICAgICAgICAgcmV0dXJuIGNlbGw7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgY29uc3QgaXNBbHJlYWR5VGhlcmUgPSBjZWxsLnBlbmNpbC5oYXModmFsdWUpO1xyXG4gICAgICAgaWYgKGlzQWxyZWFkeVRoZXJlKSB7XHJcbiAgICAgICAgIGNlbGwucGVuY2lsLmRlbGV0ZSh2YWx1ZSk7XHJcbiAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICBjZWxsLnBlbmNpbC5hZGQodmFsdWUpO1xyXG4gICAgICAgfVxyXG5cclxuICAgICAgIHJldHVybiBjZWxsO1xyXG4gICB9KTtcclxuICB9O1xyXG4gICBmdW5jdGlvbiBwYXVzZSgpIHtcclxuICAgICBjaGFuZ2VJY29uKCk7XHJcbiAgICAgc3RvcFRpbWVyKCk7XHJcblxyXG4gIH1cclxuICAgXHJcbiBcclxuXHJcbiAgIGNvbnN0IGhhbmRsZUNoYW5nZU5hdmlnYXRpb24gPSAoeyBkZXRhaWw6IHZhbHVlIH0pID0+IHtcclxuICAgIGFjdGl2ZVBvc2l0aW9uID0gdmFsdWU7XHJcbiAgIH07XHJcblxyXG4gICBjb25zdCBoYW5kbGVIaWdobGlnaHQgPSAoeyBkZXRhaWw6IHZhbHVlIH0pID0+IHtcclxuICAgICBpZiAoaGlnaGxpZ2h0VmFsdWUgPT09IHZhbHVlKSB7XHJcbiAgICAgIGhpZ2hsaWdodFZhbHVlID0gbnVsbDtcclxuICAgICB9IGVsc2Uge1xyXG4gICAgICBoaWdobGlnaHRWYWx1ZSA9IHZhbHVlO1xyXG4gICAgIH1cclxuICAgfTtcclxuXHJcbiAgICQ6IGdyb3VwZWRHcmlkID0gdXRpbHMuZ3JvdXBCeUJsb2NrKGdyaWRXaXRoQmxvY2tJbmZvKTtcclxuXHJcbiAgICQ6IGVycm9ycyA9IHV0aWxzLmdldEVycm9ycyhncmlkV2l0aEJsb2NrSW5mbyk7XHJcbiAgICQ6IG1pc3NpbmdWYWx1ZXMgPSB1dGlscy5nZXRNaXNzaW5nVmFsdWVzKGdyaWRXaXRoQmxvY2tJbmZvLCBlcnJvcnMpO1xyXG4gICAkOiBpc1ZpY3RvcnkgPSBtaXNzaW5nVmFsdWVzID09PSAwO1xyXG4gICBzdGFydEdhbWUoc2VsZWN0ZWREaWZmaWN1bHQpO1xyXG5cclxuICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcImtleWRvd25cIiwgZSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICAgY29uc3QgeyBrZXksIGN0cmxLZXkgfSA9IGU7XHJcbiAgICBjb25zdCBbaXNWYWxpZCwgYWN0aW9uXSA9IHV0aWxzLnZhbGlkYXRlS2V5SW50ZXJhY3Rpb24oa2V5LCBhY3RpdmVQb3NpdGlvbik7XHJcbiAgICAgaWYgKCFpc1ZhbGlkKSByZXR1cm47XHJcbiAgICAgaWYgKGFjdGlvbiAhPT0gXCJkaWdpdFwiKSB7XHJcbiAgICAgICBhY3RpdmVQb3NpdGlvbiA9IHV0aWxzLmdldE5ld0FjdGl2ZVBvc2l0aW9uKGFjdGl2ZVBvc2l0aW9uLCBhY3Rpb24pO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgY29uc3QgY2VsbCA9IGdyaWRXaXRoQmxvY2tJbmZvW2FjdGl2ZVBvc2l0aW9uXTtcclxuICAgICAgIGlmIChjZWxsLnJlYWRvbmx5KSByZXR1cm47XHJcblxyXG4gICAgICAgY29uc3QgZXZlbnQgPSB7XHJcbiAgICAgICAgIGRldGFpbDoge1xyXG4gICAgICAgICAgIHZhbHVlOiBwYXJzZUludChrZXksIDEwKSxcclxuICAgICAgICAgICBwb3NpdGlvbjogYWN0aXZlUG9zaXRpb25cclxuICAgICAgICB9XHJcbiAgICAgIH07XHJcblxyXG4gICAgICBjdHJsS2V5ID8gaGFuZGxlUGVuY2lsKGV2ZW50KSA6IGhhbmRsZVBlbihldmVudCk7XHJcbiAgICB9XHJcbiAgIH0pO1xyXG5cclxuIGZ1bmN0aW9uIGdvVG9DYXRlZ29yaWVzKCkge1xyXG4gICAgIHdpbmRvdy5sb2NhdGlvbi5ocmVmPVwiL2NhdGVnb3J5XCI7XHJcbiAgIH1cclxuXHJcbiAgICAgZnVuY3Rpb24gZ29Ub01hbnVhbCgpIHtcclxuICBcclxuICAgICB3aW5kb3cubG9jYXRpb24uaHJlZj1cIi9tYW51YWxcIjtcclxuICB9XHJcbjwvc2NyaXB0PlxyXG5cclxuPGhlYWRlcj5cclxuXHQ8ZGl2IGNsYXNzPVwiaGVhZGVyXCI+PGltZyBzcmM9XCJmYXZpY29uLnBuZ1wiIGFsdD1cImxvZ29cIiBoZWlnaHQ9IFwiNTBweFwiIHdpZHRoPSBcImF1dG9cIj48L2Rpdj5cclxuPC9oZWFkZXI+XHJcblxyXG48bWFpbj5cclxuICA8YnV0dG9uIG5hbWU9XCJiYWNrXCIgY2xhc3M9XCJiYWNrIG1hbnVhbFwiIG9uOmNsaWNrPXtnb1RvQ2F0ZWdvcmllc30+JiM4NjE3PC9idXR0b24+XHJcbiAgPGJ1dHRvbiBuYW1lPVwiaW5mb1wiIGNsYXNzPVwiaW5mb1wiIG9uOmNsaWNrPXtnb1RvTWFudWFsfT5pPC9idXR0b24+XHJcblxyXG4gIDxkaXYgY2xhc3M9XCJjb250YWluZXJcIj5cclxuICBcclxuICAgIDxkaXYgY2xhc3M9XCJncmlkXCI+XHJcbiAgICAgIHsjZWFjaCBncm91cGVkR3JpZCBhcyBibG9ja31cclxuICAgICAgICA8ZGl2IGNsYXNzPVwiYmxvY2tcIj5cclxuICAgICAgICAgIHsjZWFjaCBibG9jayBhcyBjZWxsfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY2VsbFwiPlxyXG4gICAgICAgICAgICAgIDxDZWxsXHJcbiAgICAgICAgICAgICAgICBvbjpjaGFuZ2UtbmF2aWdhdGlvbj17aGFuZGxlQ2hhbmdlTmF2aWdhdGlvbn1cclxuICAgICAgICAgICAgICAgIG9uOmhpZ2hsaWdodD17aGFuZGxlSGlnaGxpZ2h0fVxyXG4gICAgICAgICAgICAgICAgb246cGVuPXtoYW5kbGVQZW59XHJcbiAgICAgICAgICAgICAgICBvbjpwZW5jaWw9e2hhbmRsZVBlbmNpbH1cclxuICAgICAgICAgICAgICAgIHtjZWxsfVxyXG4gICAgICAgICAgICAgICAge2FjdGl2ZVBvc2l0aW9ufVxyXG4gICAgICAgICAgICAgICAge2hpZ2hsaWdodFZhbHVlfSAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIHsvZWFjaH1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgey9lYWNofVxyXG4gICAgPC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3M9XCJtZW51ZVwiPlxyXG4gICAgICA8ZGl2PjwvZGl2PlxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJ0aW1lclwiPnttaW51dGVzfTp7c2Vjb25kc308YnV0dG9uIGlkPVwicGF1c2VcIiBjbGFzcz1cInBhdXNlXCIgb246Y2xpY2s9e3BhdXNlfT58fDwvYnV0dG9uPjwvZGl2PlxyXG4gICAgICAgIDxidXR0b24gY2xhc3M9XCJidXR0b25cIiBpZD1cImNoZWNrXCIgb246Y2xpY2s9e2NoZWNrfT7DnGJlcnByw7xmZW48L2J1dHRvbj5cclxuICAgICAgICA8YnV0dG9uIGNsYXNzPVwiYnV0dG9uXCIgaWQ9XCJ0aXBcIiBvbjpjbGljaz17dGlwfT5IaW53ZWlzZTwvYnV0dG9uPlxyXG4gICAgICAgIDxidXR0b24gY2xhc3M9XCJidXR0b25cIiBpZD1cInJlc3RhcnRcIiBvbjpjbGljaz17cmVzdGFydH0+TmV1IHN0YXJ0ZW48L2J1dHRvbj5cclxuICAgICAgPC9kaXY+XHJcbiAgPC9kaXY+XHJcbjwvbWFpbj4gLS0+XHJcblxyXG5cclxuXHJcblxyXG48c3R5bGU+XHJcblxyXG4gIC5ncmlkOmVuYWJsZWQge1xyXG4gICAgei1pbmRleDogMTtcclxuICB9XHJcbiAgLmNvbnRhaW5lciB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcblxyXG4gIH1cclxuICAuZ3JpZCB7XHJcbiAgICBkaXNwbGF5OiBncmlkO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogYmx1ZTtcclxuICAgIGdyaWQtdGVtcGxhdGUtY29sdW1uczogYXV0byBhdXRvIGF1dG87XHJcbiAgICB3aWR0aDogNjIwcHg7XHJcbiAgICBoZWlnaHQ6IDYyMHB4O1xyXG4gICAgZ3JpZC1nYXA6IDZweDtcclxuICBcclxuXHJcbiAgfVxyXG4gIC5ibG9jayB7XHJcbiAgICBkaXNwbGF5OiBncmlkO1xyXG4gICAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiBhdXRvIGF1dG8gYXV0bztcclxuICB9XHJcbiAgLmNlbGwge1xyXG4gICAgZGlzcGxheTogZ3JpZDtcclxuICAgIC8qIGhlaWdodDogY2FsYyg2MjBweCAvIDkpOyAqL1xyXG4gICAgaGVpZ2h0OiBhdXRvO1xyXG4gICAgIGdyaWQtdGVtcGxhdGUtY29sdW1uczogYXV0byBhdXRvIGF1dG87XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIHVzZXItc2VsZWN0OiBub25lO1xyXG4gICAgd2lkdGg6IGF1dG87XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCB3aGl0ZTtcclxuICB9XHJcbiAgLm1lbnVlIHtcclxuICAgIGRpc3BsYXk6IGdyaWQ7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIGhlaWdodDogMzUwcHg7XHJcbiAgICB3aWR0aDogMjUwcHg7XHJcbiAgICBncmlkLXRlbXBsYXRlLXJvd3M6IDIwcHggYXV0byBhdXRvIGF1dG8gYXV0bztcclxuICAgIGJvcmRlcjogM3B4IHNvbGlkIHdoaXRlO1xyXG4gICAgbWFyZ2luLWxlZnQ6IDIwMHB4O1xyXG4gICAgXHJcbiAgfVxyXG4gICAgLnRpbWVyIHtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgIHRleHQtYWxpZ246IHJpZ2h0O1xyXG4gIFx0Zm9udC1zaXplOiAyMnB4O1xyXG5cdFx0Zm9udC1mYW1pbHk6IENhbGlicmk7XHJcblx0XHRmb250LXdlaWdodDogMTA7XHJcbiAgfVxyXG4gIC5wYXVzZSB7XHJcbiAgICBoZWlnaHQ6IDQwcHg7XHJcbiAgICB3aWR0aDogNDBweDtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNjMjdjOTA7XHJcbiAgICBtYXJnaW4tbGVmdDogNDBweDtcclxuICAgIGZvbnQtc2l6ZTogMjBweDtcclxuICAgIGZvbnQtd2VpZ2h0OiA3MDA7XHJcbiAgICBmb250LWZhbWlseTogJ0dpbGwgU2FucycsICdHaWxsIFNhbnMgTVQnLCBDYWxpYnJpLCAnVHJlYnVjaGV0IE1TJywgc2Fucy1zZXJpZjsgXHJcblx0XHRib3JkZXI6IG5vbmU7XHJcblx0XHRib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgfVxyXG4gIC5pbmZvIHtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNjMjdjOTA7XHJcbiAgICBoZWlnaHQ6IDQ1cHg7XHJcblx0XHR3aWR0aDogNDVweDtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICBmb250LXNpemU6IDM1cHg7XHJcbiAgICBmb250LXdlaWdodDogOTAwO1xyXG4gICAgZm9udC1mYW1pbHk6ICdUaW1lcyBOZXcgUm9tYW4nLCBUaW1lcywgc2VyaWY7IFxyXG5cdFx0Ym9yZGVyOiBub25lO1xyXG5cdFx0Ym9yZGVyLXJhZGl1czogNTAlO1xyXG4gICAgbWFyZ2luLXRvcDogLTU1cHg7XHJcblx0XHRtYXJnaW4tbGVmdDogOTUlO1xyXG4gIH1cclxuXHJcblxyXG4gICNjaGVjayB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZTE4MmFjO1xyXG4gICBcclxuICB9XHJcbiAgI3RpcCB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjYzI3YzkwO1xyXG4gIFxyXG4gIH1cclxuICAjcmVzdGFydCB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjOWM0ZDVmO1xyXG4gIFxyXG4gIH1cclxuXHJcbkBtZWRpYSAobWluLXdpZHRoOjIwMDBweCl7XHJcbiAgXHJcbi5ncmlkOmVuYWJsZWQge1xyXG4gICAgei1pbmRleDogMTtcclxuICB9XHJcbiAgLmNvbnRhaW5lciB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcblxyXG4gIH1cclxuICAuZ3JpZCB7XHJcbiAgICBkaXNwbGF5OiBncmlkO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogYmx1ZTtcclxuICAgIGdyaWQtdGVtcGxhdGUtY29sdW1uczogYXV0byBhdXRvIGF1dG87XHJcbiAgICB3aWR0aDogOTAwcHg7XHJcbiAgICBoZWlnaHQ6IDkwMHB4O1xyXG4gICAgZ3JpZC1nYXA6IDZweDtcclxuICBcclxuXHJcbiAgfVxyXG4gIC5ibG9jayB7XHJcbiAgICBkaXNwbGF5OiBncmlkO1xyXG4gICAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiBhdXRvIGF1dG8gYXV0bztcclxuICB9XHJcbiAgLmNlbGwge1xyXG4gICAgZGlzcGxheTogZ3JpZDtcclxuICAgIC8qIGhlaWdodDogY2FsYyg2MjBweCAvIDkpOyAqL1xyXG4gICAgaGVpZ2h0OiBhdXRvO1xyXG4gICAgIGdyaWQtdGVtcGxhdGUtY29sdW1uczogYXV0byBhdXRvIGF1dG87XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIHVzZXItc2VsZWN0OiBub25lO1xyXG4gICAgd2lkdGg6IGF1dG87XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCB3aGl0ZTtcclxuICB9XHJcbiAgLm1lbnVlIHtcclxuICAgIGRpc3BsYXk6IGdyaWQ7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIGhlaWdodDogNDUwcHg7XHJcbiAgICB3aWR0aDogMzUwcHg7XHJcbiAgICBncmlkLXRlbXBsYXRlLXJvd3M6IDIwcHggYXV0byBhdXRvIGF1dG8gYXV0bztcclxuICAgIGJvcmRlcjogM3B4IHNvbGlkIHdoaXRlO1xyXG4gICAgbWFyZ2luLWxlZnQ6IDIwMHB4O1xyXG4gICAgXHJcbiAgfVxyXG4gICAgLnRpbWVyIHtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgIHRleHQtYWxpZ246IHJpZ2h0O1xyXG4gIFx0Zm9udC1zaXplOiA0NXB4O1xyXG5cdFx0Zm9udC1mYW1pbHk6IENhbGlicmk7XHJcblx0XHRmb250LXdlaWdodDogMTA7XHJcbiAgfVxyXG4gIC5wYXVzZSB7XHJcbiAgICBoZWlnaHQ6IDU1cHg7XHJcbiAgICB3aWR0aDogNTVweDtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNjMjdjOTA7XHJcbiAgICBtYXJnaW4tbGVmdDogMzBweDtcclxuICAgIGZvbnQtc2l6ZTogMzVweDtcclxuICAgIGZvbnQtd2VpZ2h0OiA3MDA7XHJcbiAgICBmb250LWZhbWlseTogJ0dpbGwgU2FucycsICdHaWxsIFNhbnMgTVQnLCBDYWxpYnJpLCAnVHJlYnVjaGV0IE1TJywgc2Fucy1zZXJpZjsgXHJcblx0XHRib3JkZXI6IG5vbmU7XHJcblx0XHRib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgfVxyXG4gIC5pbmZvIHtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNjMjdjOTA7XHJcbiAgICBoZWlnaHQ6IDU1cHg7XHJcblx0XHR3aWR0aDogNTVweDtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICBmb250LXNpemU6IDQwcHg7XHJcbiAgICBmb250LXdlaWdodDogOTAwO1xyXG4gICAgZm9udC1mYW1pbHk6ICdUaW1lcyBOZXcgUm9tYW4nLCBUaW1lcywgc2VyaWY7IFxyXG5cdFx0Ym9yZGVyOiBub25lO1xyXG5cdFx0Ym9yZGVyLXJhZGl1czogNTAlO1xyXG4gICAgbWFyZ2luLXRvcDogMTBweDtcclxuXHRcdG1hcmdpbi1sZWZ0OiA5MCU7XHJcbiAgfVxyXG4gIC5idXR0b24ge1xyXG5cdFx0Y29sb3I6IHllbGxvdztcclxuXHRcdHRleHQtYWxpZ246IGNlbnRlcjtcclxuXHRcdGZvbnQtc2l6ZTogMzBweDtcclxuXHRcdGZvbnQtZmFtaWx5OiAgQ2FsaWJyaTtcclxuXHRcdGZvbnQtd2VpZ2h0OiAxMDtcclxuXHRcdGxldHRlci1zcGFjaW5nOiAwLjAzZW07XHJcblx0XHRib3JkZXI6IG5vbmU7XHJcblx0XHRib3JkZXItcmFkaXVzOiAwLjFlbTtcclxuXHQgIGhlaWdodDogNjVweDtcclxuXHRcdHdpZHRoOiAyMDBweDtcclxuXHRcdGN1cnNvcjogcG9pbnRlcjtcclxuXHRcdGRpc3BsYXk6IGJsb2NrO1xyXG5cdFx0bWFyZ2luLXJpZ2h0OiBhdXRvO1xyXG5cdFx0bWFyZ2luLWJvdHRvbTogMTVweDtcclxuXHRcdG1hcmdpbi1sZWZ0OiBhdXRvO1xyXG5cdH1cclxuXHJcblxyXG4gICNjaGVjayB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZTE4MmFjO1xyXG4gICBcclxuICB9XHJcbiAgI3RpcCB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjYzI3YzkwO1xyXG4gIFxyXG4gIH1cclxuICAjcmVzdGFydCB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjOWM0ZDVmO1xyXG4gIFxyXG4gIH1cclxuICAuaGVhZGVyIHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG5cdGhlaWdodDogMTAwcHg7XHJcbn1cclxuaW1nIHtcclxuICAgIGhlaWdodDoxMDBweDtcclxuICAgIHdpZHRoOmF1dG87XHJcbn1cclxuICB9XHJcbjwvc3R5bGU+ICJdLCJuYW1lcyI6WyJsaW5lYXIiLCJ1dGlscy5nZW5lcmF0ZUdyaWQiLCJ1dGlscy5maWxsR3JpZCIsInV0aWxzLmFwcGx5R2FtZURpZmZpY3VsdCIsInV0aWxzLmluY2x1ZGVCbG9ja0luZm8iLCJpc0xlZ2FsIiwidXRpbHMuaXNMZWdhbCIsInV0aWxzLnZhbGlkYXRlS2V5SW50ZXJhY3Rpb24iLCJ1dGlscy5nZXROZXdBY3RpdmVQb3NpdGlvbiIsInV0aWxzLmdyb3VwQnlCbG9jayIsInV0aWxzLmdldEVycm9ycyIsInV0aWxzLmdldE1pc3NpbmdWYWx1ZXMiXSwibWFwcGluZ3MiOiI7Ozs7QUFBQSxNQUFNLE9BQU8sR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUMvRSxJQUFJLENBQUM7QUFDTCxJQUFHO0FBQ0g7QUFDQSxFQUFFLE1BQU0sT0FBTyxHQUFHO0FBQ2xCLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDOUMsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUM5QyxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQzlDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFDO0FBQ1g7QUFDQSxFQUFTLE1BQU0sWUFBWSxHQUFHLENBQUMsU0FBUyxHQUFHLENBQUMsS0FBSztBQUNqRCxJQUFJLE1BQU0sUUFBUSxHQUFHLFNBQVMsS0FBSyxDQUFDLEdBQUcsRUFBRSxHQUFHLEdBQUU7QUFDOUMsSUFBSSxPQUFPLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ2xDLElBQUc7QUFDSDtBQUNBLEVBQUUsTUFBTSxPQUFPLEdBQUcsQ0FBQyxJQUFJO0FBQ3ZCLElBQUksS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFO0FBQzNDLE1BQU0sTUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO0FBQ25ELE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDO0FBQ2xDLEtBQUs7QUFDTCxJQUFJLE9BQU8sQ0FBQztBQUNaLElBQUc7QUFDSDtBQUNBLEVBQVMsTUFBTSxRQUFRLEdBQUcsQ0FBQyxJQUFJLEVBQUUsU0FBUyxHQUFHLENBQUMsS0FBSztBQUNuRCxJQUFJLE1BQU0sUUFBUSxHQUFHLFNBQVMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUM7QUFDNUM7QUFDQSxJQUFJLE1BQU0sS0FBSyxHQUFHLEdBQUU7QUFDcEIsSUFBSSxJQUFJLFlBQVksR0FBRyxFQUFDO0FBQ3hCLElBQUksSUFBSSxZQUFZLEdBQUcsSUFBSSxDQUFDLFlBQVksRUFBQztBQUN6QztBQUNBLElBQUksSUFBSSxPQUFPLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBQztBQUN0RCxJQUFJLElBQUksV0FBVyxHQUFHLEVBQUM7QUFDdkI7QUFDQSxJQUFJLE9BQU8sUUFBUSxDQUFDLElBQUksQ0FBQyxFQUFFO0FBQzNCLE1BQU0sSUFBSSxZQUFZLEtBQUssQ0FBQyxFQUFFO0FBQzlCLFFBQVE7QUFDUixVQUFVLE9BQU8sQ0FBQyxJQUFJLEVBQUUsWUFBWSxFQUFFLE9BQU8sQ0FBQyxXQUFXLENBQUMsRUFBRSxTQUFTLENBQUM7QUFDdEUsVUFBVSxXQUFXLEdBQUcsUUFBUTtBQUNoQyxVQUFVO0FBQ1YsVUFBVSxJQUFJLENBQUMsWUFBWSxDQUFDLEdBQUcsT0FBTyxDQUFDLFdBQVcsRUFBQztBQUNuRCxVQUFVLEtBQUssQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFDO0FBQ2xDLFVBQVUsT0FBTyxHQUFHLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUM7QUFDeEQsVUFBVSxXQUFXLEdBQUcsQ0FBQyxFQUFDO0FBQzFCLFVBQVUsWUFBWSxHQUFHLFlBQVksR0FBRyxFQUFDO0FBQ3pDLFVBQVUsWUFBWSxHQUFHLElBQUksQ0FBQyxZQUFZLEVBQUM7QUFDM0MsU0FBUyxNQUFNLElBQUksV0FBVyxHQUFHLFFBQVEsR0FBRyxDQUFDLEVBQUU7QUFDL0MsVUFBVSxJQUFJLENBQUMsWUFBWSxDQUFDLEdBQUcsRUFBQztBQUNoQyxVQUFVLFlBQVksR0FBRyxLQUFLLENBQUMsR0FBRyxHQUFFO0FBQ3BDLFVBQVUsV0FBVyxHQUFHLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFDO0FBQzNELFVBQVUsSUFBSSxDQUFDLFlBQVksQ0FBQyxHQUFHLEVBQUM7QUFDaEMsU0FBUztBQUNULE9BQU8sTUFBTTtBQUNiLFFBQVEsWUFBWSxHQUFHLFlBQVksR0FBRyxFQUFDO0FBQ3ZDLFFBQVEsWUFBWSxHQUFHLElBQUksQ0FBQyxZQUFZLEVBQUM7QUFDekMsUUFBUSxPQUFPLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBQztBQUN0RCxRQUFRLFdBQVcsR0FBRyxDQUFDLEVBQUM7QUFDeEIsT0FBTztBQUNQLE1BQU0sV0FBVyxHQUFHLFdBQVcsR0FBRyxFQUFDO0FBQ25DLEtBQUs7QUFDTCxJQUFJLE9BQU8sSUFBSTtBQUNmLElBQUc7QUFDSDtBQUNBLEVBQVMsTUFBTSxnQkFBZ0IsR0FBRyxDQUFDLElBQUksRUFBRSxTQUFTLEdBQUcsQ0FBQyxLQUFLO0FBQzNELElBQUksTUFBTSxNQUFNLEdBQUcsU0FBUyxLQUFLLENBQUMsR0FBRyxPQUFPLEdBQUcsUUFBTztBQUN0RDtBQUNBLElBQUksT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxFQUFFLEtBQUssTUFBTTtBQUN0QyxNQUFNLEtBQUssRUFBRSxJQUFJO0FBQ2pCLE1BQU0sS0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLLENBQUM7QUFDMUIsTUFBTSxRQUFRLEVBQUUsS0FBSztBQUNyQixNQUFNLFFBQVEsRUFBRSxDQUFDLENBQUMsSUFBSTtBQUN0QixNQUFNLE1BQU0sRUFBRSxJQUFJLEdBQUcsRUFBRTtBQUN2QixLQUFLLENBQUMsQ0FBQztBQUNQLElBQUc7QUFDSDtBQUNBLEVBQVMsTUFBTSxZQUFZLEdBQUcsSUFBSSxJQUFJO0FBQ3RDLElBQUksT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxFQUFFLElBQUksS0FBSztBQUN0QztBQUNBLE1BQU0sTUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLEtBQUssR0FBRyxFQUFDO0FBQ2xDO0FBQ0EsTUFBTSxJQUFJLEdBQUcsQ0FBQyxLQUFLLENBQUMsRUFBRTtBQUN0QixRQUFRLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFDO0FBQzdCLE9BQU8sTUFBTTtBQUNiLFFBQVEsR0FBRyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsSUFBSSxFQUFDO0FBQzNCLE9BQU87QUFDUCxNQUFNLE9BQU8sR0FBRztBQUNoQixLQUFLLEVBQUUsRUFBRSxDQUFDO0FBQ1YsSUFBRztBQUNIO0FBQ0E7QUFDQTtBQUNBLEVBQUUsTUFBTSxhQUFhLEdBQUc7QUFDeEIsSUFBSSxJQUFJLEVBQUUsRUFBRTtBQUNaLElBQUksTUFBTSxFQUFFLEVBQUU7QUFDZCxJQUFJLElBQUksRUFBRSxFQUFFO0FBQ1osSUFBRztBQUNIO0FBQ0E7QUFDQSxFQUFTLE1BQU0sa0JBQWtCLEdBQUcsQ0FBQyxTQUFTLEVBQUUsSUFBSSxLQUFLO0FBQ3pELElBQUksTUFBTSxPQUFPLEdBQUcsSUFBSSxHQUFHLEdBQUU7QUFDN0I7QUFDQSxJQUFJLE9BQU8sT0FBTyxDQUFDLElBQUksS0FBSyxFQUFFLEdBQUcsYUFBYSxDQUFDLFNBQVMsQ0FBQyxFQUFFO0FBQzNELE1BQU0sTUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLEdBQUcsRUFBRSxFQUFDO0FBQ3hEO0FBQ0E7QUFDQSxNQUFNLE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFDO0FBQzlCLEtBQUs7QUFDTCxJQUFJLEtBQUssTUFBTSxLQUFLLElBQUksT0FBTyxFQUFFO0FBQ2pDLE1BQU0sSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLEtBQUk7QUFDeEIsS0FBSztBQUNMLElBQUksT0FBTyxJQUFJO0FBQ2YsSUFBRztBQUNIO0FBQ0EsRUFBUyxNQUFNLE9BQU8sR0FBRyxDQUFDLElBQUksRUFBRSxRQUFRLEVBQUUsTUFBTSxFQUFFLFNBQVMsR0FBRyxDQUFDLEtBQUs7QUFDcEUsSUFBSSxNQUFNLFdBQVcsR0FBRyxJQUFJLEdBQUcsR0FBRTtBQUNqQztBQUNBLElBQUksTUFBTSxRQUFRLEdBQUcsU0FBUyxLQUFLLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBQztBQUM1QyxJQUFJLE1BQU0sTUFBTSxHQUFHLFNBQVMsS0FBSyxDQUFDLEdBQUcsT0FBTyxHQUFHLFFBQU87QUFDdEQ7QUFDQTtBQUNBLElBQUksTUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLEdBQUcsUUFBUSxFQUFDO0FBQy9DLElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksRUFBRSxLQUFLLEtBQUs7QUFDbEMsTUFBTSxJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxHQUFHLFFBQVEsQ0FBQyxLQUFLLEdBQUcsRUFBRTtBQUNoRCxRQUFRLFdBQVcsQ0FBQyxHQUFHLENBQUMsSUFBSSxFQUFDO0FBQzdCLE9BQU87QUFDUCxLQUFLLEVBQUM7QUFDTjtBQUNBO0FBQ0EsSUFBSSxNQUFNLE1BQU0sR0FBRyxRQUFRLEdBQUcsU0FBUTtBQUN0QyxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLEVBQUUsS0FBSyxLQUFLO0FBQ2xDLE1BQU0sSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssR0FBRyxRQUFRLENBQUMsS0FBSyxNQUFNLEVBQUU7QUFDbkQsUUFBUSxXQUFXLENBQUMsR0FBRyxDQUFDLElBQUksRUFBQztBQUM3QixPQUFPO0FBQ1AsS0FBSyxFQUFDO0FBQ047QUFDQTtBQUNBLElBQUksTUFBTSxLQUFLLEdBQUcsTUFBTSxDQUFDLFFBQVEsRUFBQztBQUNsQyxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLEVBQUUsS0FBSyxLQUFLO0FBQ2xDLE1BQU0sSUFBSSxNQUFNLENBQUMsS0FBSyxDQUFDLEtBQUssS0FBSyxFQUFFO0FBQ25DLFFBQVEsV0FBVyxDQUFDLEdBQUcsQ0FBQyxJQUFJLEVBQUM7QUFDN0IsT0FBTztBQUNQLEtBQUssRUFBQztBQUNOO0FBQ0EsSUFBSSxPQUFPLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUM7QUFDbkMsSUFBRztBQUNIO0FBQ0EsRUFBUyxNQUFNLFFBQVEsR0FBRyxJQUFJLElBQUk7QUFDbEMsSUFBSSxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxJQUFJLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLEtBQUssQ0FBQztBQUN2RCxJQUFHO0FBQ0g7QUFDQSxFQUFTLE1BQU0sa0JBQWtCLEdBQUcsQ0FBQyxZQUFZLEVBQUUsU0FBUyxHQUFHLENBQUMsS0FBSztBQUNyRSxJQUFJLE1BQU0sUUFBUSxHQUFHLFNBQVMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUM7QUFDNUMsSUFBSSxJQUFJLEtBQUssR0FBRyxLQUFJO0FBQ3BCO0FBQ0EsSUFBSSxPQUFPLENBQUMsS0FBSyxFQUFFO0FBQ25CLE1BQU0sTUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLEdBQUcsUUFBUSxDQUFDLEdBQUcsRUFBQztBQUM3RCxNQUFNLElBQUksQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxFQUFFO0FBQ3JDLFFBQVEsS0FBSyxHQUFHLE9BQU07QUFDdEIsT0FBTztBQUNQLEtBQUs7QUFDTCxJQUFJLE9BQU8sS0FBSztBQUNoQixJQUFHO0FBQ0g7QUFDQSxFQUFTLE1BQU0sU0FBUyxHQUFHLElBQUksSUFBSTtBQUNuQyxJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU07QUFDakQsSUFBRztBQUNIO0FBQ0EsRUFBUyxNQUFNLGdCQUFnQixHQUFHLENBQUMsSUFBSSxFQUFFLE1BQU0sS0FBSztBQUNwRCxJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLEtBQUssS0FBSyxJQUFJLENBQUMsQ0FBQyxNQUFNLEdBQUcsTUFBTTtBQUNuRSxJQUFHO0FBQ0g7QUFDQSxFQUFTLE1BQU0sc0JBQXNCLEdBQUcsQ0FBQyxHQUFHLEVBQUUsUUFBUSxLQUFLO0FBQzNELElBQUksTUFBTSxLQUFLLEdBQUcsUUFBUSxDQUFDLEdBQUcsRUFBRSxFQUFFLEVBQUM7QUFDbkM7QUFDQSxJQUFJLElBQUksR0FBRyxLQUFLLFdBQVcsSUFBSSxRQUFRLEdBQUcsRUFBRSxFQUFFO0FBQzlDLE1BQU0sT0FBTyxDQUFDLElBQUksRUFBRSxNQUFNLENBQUM7QUFDM0IsS0FBSyxNQUFNLElBQUksR0FBRyxLQUFLLFNBQVMsSUFBSSxRQUFRLEdBQUcsQ0FBQyxFQUFFO0FBQ2xELE1BQU0sT0FBTyxDQUFDLElBQUksRUFBRSxJQUFJLENBQUM7QUFDekIsS0FBSyxNQUFNLElBQUksR0FBRyxLQUFLLFdBQVcsSUFBSSxRQUFRLEdBQUcsQ0FBQyxHQUFHLENBQUMsRUFBRTtBQUN4RCxNQUFNLE9BQU8sQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDO0FBQzNCLEtBQUssTUFBTSxJQUFJLEdBQUcsS0FBSyxZQUFZLElBQUksUUFBUSxHQUFHLENBQUMsR0FBRyxDQUFDLEVBQUU7QUFDekQsTUFBTSxPQUFPLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQztBQUM1QixLQUFLLE1BQU0sSUFBSSxNQUFNLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxFQUFFO0FBQ3hDLE1BQU0sT0FBTyxDQUFDLElBQUksRUFBRSxPQUFPLENBQUM7QUFDNUIsS0FBSztBQUNMO0FBQ0EsSUFBSSxPQUFPLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQztBQUN4QixJQUFHO0FBQ0g7QUFDQSxFQUFTLE1BQU0sb0JBQW9CLEdBQUcsQ0FBQyxRQUFRLEVBQUUsTUFBTSxLQUFLO0FBQzVELElBQUksSUFBSSxNQUFNLEtBQUssTUFBTSxFQUFFO0FBQzNCLE1BQU0sT0FBTyxRQUFRLEdBQUcsQ0FBQztBQUN6QixLQUFLLE1BQU0sSUFBSSxNQUFNLEtBQUssSUFBSSxFQUFFO0FBQ2hDLE1BQU0sT0FBTyxRQUFRLEdBQUcsQ0FBQztBQUN6QixLQUFLLE1BQU0sSUFBSSxNQUFNLEtBQUssTUFBTSxFQUFFO0FBQ2xDLE1BQU0sT0FBTyxRQUFRLEdBQUcsQ0FBQztBQUN6QixLQUFLLE1BQU0sSUFBSSxNQUFNLEtBQUssT0FBTyxFQUFFO0FBQ25DLE1BQU0sT0FBTyxRQUFRLEdBQUcsQ0FBQztBQUN6QixLQUFLO0FBQ0w7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2xNQSxTQUFTLE9BQU8sQ0FBQyxHQUFHLEVBQUU7QUFDdEIsSUFBSSxPQUFPLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxlQUFlLENBQUM7QUFDbkUsQ0FBQztBQTBHRDtBQUNBLFNBQVMsZ0JBQWdCLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRTtBQUNoQyxJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQztBQUMxQixRQUFRLE9BQU8sTUFBTSxDQUFDLENBQUM7QUFDdkIsSUFBSSxNQUFNLElBQUksR0FBRyxPQUFPLENBQUMsQ0FBQztBQUMxQixJQUFJLElBQUksSUFBSSxLQUFLLE9BQU8sQ0FBQyxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRTtBQUNwRSxRQUFRLE1BQU0sSUFBSSxLQUFLLENBQUMsNkNBQTZDLENBQUMsQ0FBQztBQUN2RSxLQUFLO0FBQ0wsSUFBSSxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUU7QUFDMUIsUUFBUSxNQUFNLEdBQUcsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsS0FBSztBQUNyQyxZQUFZLE9BQU8sZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzlDLFNBQVMsQ0FBQyxDQUFDO0FBQ1gsUUFBUSxPQUFPLENBQUMsSUFBSSxHQUFHLENBQUMsR0FBRyxDQUFDLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6QyxLQUFLO0FBQ0wsSUFBSSxJQUFJLElBQUksS0FBSyxRQUFRLEVBQUU7QUFDM0IsUUFBUSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNwQixZQUFZLE1BQU0sSUFBSSxLQUFLLENBQUMsdUJBQXVCLENBQUMsQ0FBQztBQUNyRCxRQUFRLElBQUksT0FBTyxDQUFDLENBQUMsQ0FBQyxJQUFJLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRTtBQUN0QyxZQUFZLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBTyxFQUFFLENBQUM7QUFDNUIsWUFBWSxDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sRUFBRSxDQUFDO0FBQzVCLFlBQVksTUFBTSxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNoQyxZQUFZLE9BQU8sQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsS0FBSyxDQUFDLENBQUM7QUFDaEQsU0FBUztBQUNULFFBQVEsTUFBTSxJQUFJLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwQyxRQUFRLE1BQU0sYUFBYSxHQUFHLEVBQUUsQ0FBQztBQUNqQyxRQUFRLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxJQUFJO0FBQzVCLFlBQVksYUFBYSxDQUFDLEdBQUcsQ0FBQyxHQUFHLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztBQUNsRSxTQUFTLENBQUMsQ0FBQztBQUNYLFFBQVEsT0FBTyxDQUFDLElBQUk7QUFDcEIsWUFBWSxNQUFNLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFDOUIsWUFBWSxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsSUFBSTtBQUNoQyxnQkFBZ0IsTUFBTSxDQUFDLEdBQUcsQ0FBQyxHQUFHLGFBQWEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwRCxhQUFhLENBQUMsQ0FBQztBQUNmLFlBQVksT0FBTyxNQUFNLENBQUM7QUFDMUIsU0FBUyxDQUFDO0FBQ1YsS0FBSztBQUNMLElBQUksSUFBSSxJQUFJLEtBQUssUUFBUSxFQUFFO0FBQzNCLFFBQVEsTUFBTSxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUM1QixRQUFRLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsS0FBSyxDQUFDO0FBQ2xDLEtBQUs7QUFDTCxJQUFJLE1BQU0sSUFBSSxLQUFLLENBQUMsQ0FBQyxtQkFBbUIsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztBQUN6RCxDQUFDO0FBQ0QsU0FBUyxPQUFPLENBQUMsS0FBSyxFQUFFLFFBQVEsR0FBRyxFQUFFLEVBQUU7QUFDdkMsSUFBSSxNQUFNLEtBQUssR0FBRyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDbEMsSUFBSSxJQUFJLElBQUksQ0FBQztBQUNiLElBQUksSUFBSSxZQUFZLEdBQUcsS0FBSyxDQUFDO0FBQzdCLElBQUksU0FBUyxHQUFHLENBQUMsU0FBUyxFQUFFLElBQUksRUFBRTtBQUNsQyxRQUFRLElBQUksS0FBSyxJQUFJLElBQUksRUFBRTtBQUMzQixZQUFZLEtBQUssQ0FBQyxHQUFHLENBQUMsS0FBSyxHQUFHLFNBQVMsQ0FBQyxDQUFDO0FBQ3pDLFlBQVksT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUM7QUFDckMsU0FBUztBQUNULFFBQVEsWUFBWSxHQUFHLFNBQVMsQ0FBQztBQUNqQyxRQUFRLElBQUksYUFBYSxHQUFHLElBQUksQ0FBQztBQUNqQyxRQUFRLElBQUksT0FBTyxHQUFHLEtBQUssQ0FBQztBQUM1QixRQUFRLElBQUksRUFBRSxLQUFLLEdBQUcsQ0FBQyxFQUFFLFFBQVEsR0FBRyxHQUFHLEVBQUUsTUFBTSxHQUFHQSxRQUFNLEVBQUUsV0FBVyxHQUFHLGdCQUFnQixFQUFFLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsUUFBUSxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7QUFDaEksUUFBUSxJQUFJLFFBQVEsS0FBSyxDQUFDLEVBQUU7QUFDNUIsWUFBWSxJQUFJLGFBQWEsRUFBRTtBQUMvQixnQkFBZ0IsYUFBYSxDQUFDLEtBQUssRUFBRSxDQUFDO0FBQ3RDLGdCQUFnQixhQUFhLEdBQUcsSUFBSSxDQUFDO0FBQ3JDLGFBQWE7QUFDYixZQUFZLEtBQUssQ0FBQyxHQUFHLENBQUMsS0FBSyxHQUFHLFlBQVksQ0FBQyxDQUFDO0FBQzVDLFlBQVksT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUM7QUFDckMsU0FBUztBQUNULFFBQVEsTUFBTSxLQUFLLEdBQUcsR0FBRyxFQUFFLEdBQUcsS0FBSyxDQUFDO0FBQ3BDLFFBQVEsSUFBSSxFQUFFLENBQUM7QUFDZixRQUFRLElBQUksR0FBRyxJQUFJLENBQUMsR0FBRyxJQUFJO0FBQzNCLFlBQVksSUFBSSxHQUFHLEdBQUcsS0FBSztBQUMzQixnQkFBZ0IsT0FBTyxJQUFJLENBQUM7QUFDNUIsWUFBWSxJQUFJLENBQUMsT0FBTyxFQUFFO0FBQzFCLGdCQUFnQixFQUFFLEdBQUcsV0FBVyxDQUFDLEtBQUssRUFBRSxTQUFTLENBQUMsQ0FBQztBQUNuRCxnQkFBZ0IsSUFBSSxPQUFPLFFBQVEsS0FBSyxVQUFVO0FBQ2xELG9CQUFvQixRQUFRLEdBQUcsUUFBUSxDQUFDLEtBQUssRUFBRSxTQUFTLENBQUMsQ0FBQztBQUMxRCxnQkFBZ0IsT0FBTyxHQUFHLElBQUksQ0FBQztBQUMvQixhQUFhO0FBQ2IsWUFBWSxJQUFJLGFBQWEsRUFBRTtBQUMvQixnQkFBZ0IsYUFBYSxDQUFDLEtBQUssRUFBRSxDQUFDO0FBQ3RDLGdCQUFnQixhQUFhLEdBQUcsSUFBSSxDQUFDO0FBQ3JDLGFBQWE7QUFDYixZQUFZLE1BQU0sT0FBTyxHQUFHLEdBQUcsR0FBRyxLQUFLLENBQUM7QUFDeEMsWUFBWSxJQUFJLE9BQU8sR0FBRyxRQUFRLEVBQUU7QUFDcEMsZ0JBQWdCLEtBQUssQ0FBQyxHQUFHLENBQUMsS0FBSyxHQUFHLFNBQVMsQ0FBQyxDQUFDO0FBQzdDLGdCQUFnQixPQUFPLEtBQUssQ0FBQztBQUM3QixhQUFhO0FBQ2I7QUFDQSxZQUFZLEtBQUssQ0FBQyxHQUFHLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsT0FBTyxHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM5RCxZQUFZLE9BQU8sSUFBSSxDQUFDO0FBQ3hCLFNBQVMsQ0FBQyxDQUFDO0FBQ1gsUUFBUSxPQUFPLElBQUksQ0FBQyxPQUFPLENBQUM7QUFDNUIsS0FBSztBQUNMLElBQUksT0FBTztBQUNYLFFBQVEsR0FBRztBQUNYLFFBQVEsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFLElBQUksS0FBSyxHQUFHLENBQUMsRUFBRSxDQUFDLFlBQVksRUFBRSxLQUFLLENBQUMsRUFBRSxJQUFJLENBQUM7QUFDaEUsUUFBUSxTQUFTLEVBQUUsS0FBSyxDQUFDLFNBQVM7QUFDbEMsS0FBSyxDQUFDO0FBQ047Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7MERDM0JzQyxHQUFzQjsyQ0FDOUIsR0FBZTsrQkFDckIsR0FBUztxQ0FDTixHQUFZOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs4QkFOdEIsR0FBSzs7OztrQ0FBVixNQUFJOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs2QkFBQyxHQUFLOzs7O2lDQUFWLE1BQUk7Ozs7Ozs7Ozs7Ozs7Ozs7MEJBQUosTUFBSTs7Ozs7Ozs7OztvQ0FBSixNQUFJOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7a0NBRkgsR0FBVzs7OztnQ0FBaEIsTUFBSTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O3lCQW1CZ0IsR0FBTzs7eUJBQUcsR0FBTzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7MkNBQWpCLEdBQU87OzJDQUFHLEdBQU87Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7aUNBekJPLGNBQWM7aUNBQ3JCLFVBQVU7aUNBd0JrQyxLQUFLO2lDQUMxQyxLQUFLO2lDQUNQLEdBQUc7aUNBQ0MsT0FBTzs7Ozs7aUNBdEJoRCxHQUFXOzs7OytCQUFoQixNQUFJOzs7Ozs7Ozs7Ozs7Ozs7O3dCQUFKLE1BQUk7Ozs7Ozs7dUVBbUJnQixHQUFPO3VFQUFHLEdBQU87Ozs7O2tDQW5CckMsTUFBSTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1NBOUpELFdBQVcsQ0FBQyxHQUFHO0tBQ2xCLFNBQVMsR0FBRyxHQUFHLEdBQUcsRUFBRTs7S0FDcEIsU0FBUyxDQUFDLE1BQU0sR0FBRyxDQUFDO1NBQ2YsR0FBRyxHQUFHLFNBQVM7O1NBRWYsU0FBUzs7OztTQVFYLFVBQVU7S0FDYixDQUFDLEdBQUcsUUFBUSxDQUFDLGNBQWMsQ0FBQyxPQUFPOztLQUNuQyxDQUFDLENBQUMsU0FBUyxLQUFLLElBQUk7RUFDdkIsQ0FBQyxDQUFDLFNBQVMsR0FBRyxTQUFTO0VBQ3JCLFNBQVM7O0VBQ1gsQ0FBQyxDQUFDLFNBQVMsR0FBRyxJQUFJOzs7O1NBSVosS0FBSzs7OztTQUlMLE9BQU87Q0FDZCxRQUFRLENBQUMsTUFBTTs7O1NBU1IsU0FBUyxDQUFDLENBQUM7Q0FDakIsQ0FBQyxDQUFDLGNBQWM7Q0FDaEIsUUFBUSxHQUFHLElBQUk7OztTQWtEUixLQUFLO0NBQ1osVUFBVTtDQUNWLFNBQVM7OztTQStDSixjQUFjO0NBQ25CLE1BQU0sQ0FBQyxRQUFRLENBQUMsSUFBSSxHQUFDLFdBQVc7OztTQUd2QixVQUFVO0NBRW5CLE1BQU0sQ0FBQyxRQUFRLENBQUMsSUFBSSxHQUFDLFNBQVM7Ozs7O0tBeko3QixHQUFHLEdBQUcsTUFBTSxDQUFDLFFBQVEsQ0FBQyxNQUFNO0tBQzVCLGlCQUFpQixHQUFHLEdBQUcsQ0FBQyxPQUFPLENBQUMsYUFBYSxFQUFFLEVBQUU7OztLQUdqRCxLQUFLLEdBQUcsQ0FBQzs7S0FDVCxLQUFLLEdBQUcsT0FBTyxDQUFDLEtBQUs7Ozs7Q0FDekIsV0FBVzs7MEJBQ1QsTUFBTTs7RUFDTCxJQUFJOzs7S0E0Q0YsaUJBQWlCO0tBQ25CLGlCQUFpQjtLQUNoQixjQUFjLEdBQUcsQ0FBQztLQUNqQixjQUFjLEdBQUcsSUFBSTs7T0FFbkIsU0FBUyxHQUFHLFNBQVM7UUFDckIsSUFBSSxHQUFHQyxZQUFrQixDQUFDLENBQUM7UUFDMUIsVUFBVSxHQUFHQyxRQUFjLENBQUMsSUFBSSxFQUFFLENBQUM7RUFDeEMsaUJBQWlCLEdBQUdDLGtCQUF3QixDQUFDLGlCQUFpQixFQUFFLFVBQVU7bUJBQzVFLGlCQUFpQixHQUFHQyxnQkFBc0IsQ0FBQyxpQkFBaUIsRUFBRSxDQUFDOzs7T0FHekQsU0FBUyxNQUFNLE1BQU0sSUFBSSxLQUFLLEVBQUUsUUFBUTtRQUN0Q0MsU0FBTyxHQUFHQyxPQUFhLENBQUMsaUJBQWlCLEVBQUUsUUFBUSxFQUFFLEtBQUs7O21CQUNoRSxpQkFBaUIsR0FBRyxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsSUFBSTtPQUN6QyxJQUFJLENBQUMsUUFBUSxLQUFLLFFBQVE7V0FDckIsSUFBSTs7OztPQUlQLElBQUk7SUFDUCxLQUFLLEVBQUUsS0FBSyxLQUFLLENBQUMsR0FBRyxLQUFLLEdBQUcsSUFBSTtJQUNsQyxLQUFLLEVBQUUsS0FBSyxLQUFLLENBQUMsR0FBRyxLQUFLLElBQUlELFNBQU87Ozs7RUFHekMsaUJBQWlCLENBQUMsUUFBUSxJQUFJLEtBQUs7OztPQUc5QixZQUFZLE1BQU0sTUFBTSxJQUFJLEtBQUssRUFBRSxRQUFRO01BQzNDLEtBQUssS0FBSyxDQUFDOzttQkFFakIsaUJBQWlCLEdBQUcsaUJBQWlCLENBQUMsR0FBRyxDQUFDLElBQUk7T0FDdkMsSUFBSSxDQUFDLFFBQVEsS0FBSyxRQUFRO1dBQ3BCLElBQUk7OztTQUdULGNBQWMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxLQUFLOztPQUN0QyxjQUFjO0lBQ2hCLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUs7O0lBRXhCLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEtBQUs7OztVQUdoQixJQUFJOzs7O09BV1Qsc0JBQXNCLE1BQU0sTUFBTSxFQUFFLEtBQUs7a0JBQzlDLGNBQWMsR0FBRyxLQUFLOzs7T0FHakIsZUFBZSxNQUFNLE1BQU0sRUFBRSxLQUFLO01BQ2xDLGNBQWMsS0FBSyxLQUFLO21CQUMzQixjQUFjLEdBQUcsSUFBSTs7bUJBRXJCLGNBQWMsR0FBRyxLQUFLOzs7O0NBU3pCLFNBQVMsQ0FBa0I7O0NBRTVCLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLEVBQUUsQ0FBQztFQUNsQyxDQUFDLENBQUMsY0FBYztVQUNQLEdBQUcsRUFBRSxPQUFPLEtBQUssQ0FBQztTQUNwQixPQUFPLEVBQUUsTUFBTSxJQUFJRSxzQkFBNEIsQ0FBQyxHQUFHLEVBQUUsY0FBYztPQUNwRSxPQUFPOztNQUNSLE1BQU0sS0FBSyxPQUFPO21CQUNwQixjQUFjLEdBQUdDLG9CQUEwQixDQUFDLGNBQWMsRUFBRSxNQUFNOztTQUU3RCxJQUFJLEdBQUcsaUJBQWlCLENBQUMsY0FBYztPQUN4QyxJQUFJLENBQUMsUUFBUTs7U0FFWCxLQUFLO0lBQ1QsTUFBTTtLQUNKLEtBQUssRUFBRSxRQUFRLENBQUMsR0FBRyxFQUFFLEVBQUU7S0FDdkIsUUFBUSxFQUFFLGNBQWM7Ozs7R0FJN0IsT0FBTyxHQUFHLFlBQVksQ0FBQyxLQUFLLElBQUksU0FBUyxDQUFDLEtBQUs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztvQkE1SGhELE9BQU8sR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUcsRUFBRTs7OztJQUM1QyxPQUFPLEdBQUcsT0FBTyxHQUFHLENBQUMsR0FBRyxNQUFNLEdBQUcsS0FBSzs7OztvQkFDdEMsT0FBTyxHQUFHLFdBQVcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxPQUFPLEdBQUcsRUFBRTs7OztvQkFpR3JELFdBQVcsR0FBR0MsWUFBa0IsQ0FBQyxpQkFBaUI7Ozs7cUJBRWxELE1BQU0sR0FBR0MsU0FBZSxDQUFDLGlCQUFpQjs7OztxQkFDMUMsYUFBYSxHQUFHQyxnQkFBc0IsQ0FBQyxpQkFBaUIsRUFBRSxNQUFNOzs7O0lBQ2hFLFNBQVMsR0FBRyxhQUFhLEtBQUssQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzsifQ==
